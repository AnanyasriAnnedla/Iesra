import type { Config } from "tailwindcss";

const v = (n: string) => `var(--${n})`;

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        paper: v("paper"), surface: v("surface"), sunken: v("sunken"),
        ink: v("ink"), mute: v("ink-2"), faint: v("ink-3"), line: v("line"),
        reason: v("reason"), "reason-tint": v("reason-tint"),
        viz: v("viz"), "viz-tint": v("viz-tint"),
        warn: v("warn"), "warn-tint": v("warn-tint"),
        bad: v("bad"), "bad-tint": v("bad-tint"),
        ok: v("ok"), "ok-tint": v("ok-tint"),
      },
      fontFamily: {
        sans: ['"Instrument Sans Variable"', "system-ui", "sans-serif"],
        serif: ['"Newsreader Variable"', "Georgia", "serif"],
        mono: ["ui-monospace", "SFMono-Regular", "Menlo", "monospace"],
      },
      borderRadius: { xs: "4px", sm: "6px", md: "10px", lg: "14px" },
    },
  },
  plugins: [],
};
export default config;
