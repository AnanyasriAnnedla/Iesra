/** Sample data only. Titles, methods and numbers are invented so the UI can be built and demoed offline. */
import type { Diagram, Evidence, Gap, Hypothesis, CriticVerdict, PaperExtraction, PaperMeta, Report, RunState } from "./types";

type P = [string, string, number, string, number, string, string, string[], string[], string, string];
const RAW: P[] = [
  ["P01", "TemplateTalk: Rule-Based Explanations for Dialogue Recommenders", 2019, "Sample Conf. A", 84, "TemplateTalk", "Explanation generation", ["MovieLens"], ["NDCG", "BLEU"], "Explanations are rigid and repetitive.", "explanations are filled from fixed templates"],
  ["P02", "KG-Why: Knowledge-Graph Paths as Explanations in Conversation", 2020, "Sample Conf. B", 131, "KG-Why", "Explanation generation", ["MovieLens", "Yelp"], ["Hit@10", "Path validity"], "Needs a curated knowledge graph.", "we walk paths in the item knowledge graph"],
  ["P03", "ReviewGen: Generating Explanations from User Reviews", 2020, "Sample Conf. A", 97, "ReviewGen", "Explanation generation", ["Yelp"], ["BLEU", "ROUGE"], "No human evaluation of explanation quality.", "sentences are generated from review text"],
  ["P04", "DialogRec-Plan: Multi-Turn Preference Elicitation with Planning", 2021, "Sample Journal C", 142, "DialogRec-Plan", "Multi-turn dialogue", ["MovieLens", "Reddit-Movie"], ["Hit@10", "Turns to success"], "Gives no reasons for its recommendations.", "a planner decides when to ask and when to recommend"],
  ["P05", "ExplainChat: Retrieval-Grounded Explanations for Chat Recommenders", 2022, "Sample Conf. B", 76, "ExplainChat", "Explanation generation; Multi-turn dialogue", ["MovieLens", "Yelp"], ["Hit@10", "Human rating"], "Evaluated on only two datasets.", "retrieved evidence is rewritten as a reply"],
  ["P06", "ConvBandit: Bandit Questioning Strategies for Cold-Start Users", 2021, "Sample Conf. A", 58, "ConvBandit", "Multi-turn dialogue", ["Reddit-Movie"], ["Turns to success"], "Assumes users answer every question.", "a bandit picks the next question"],
  ["P07", "ReasonLM: Generative Explanations with Pretrained Language Models", 2023, "Sample Conf. D", 64, "ReasonLM", "Explanation generation", ["MovieLens", "Yelp"], ["ROUGE", "Hit@10"], "Explanations can be unfaithful to the model.", "a language model is fine-tuned to write reasons"],
  ["P08", "Trust in the Loop: A User Study of Explained Recommendations", 2022, "Sample Journal C", 49, "n/a (user study)", "Explanation generation", ["Custom survey"], ["Human rating", "Trust score"], "Small participant pool.", "participants rated explanations for trust"],
  ["P09", "UniConvRec: A Unified Dialogue and Ranking Architecture", 2023, "Sample Conf. D", 71, "UniConvRec", "Multi-turn dialogue; Explanation generation", ["MovieLens", "Reddit-Movie"], ["Hit@10", "BLEU"], "Explanations are an afterthought.", "one model handles dialogue and ranking"],
  ["P10", "FaithExplain: Measuring Explanation Faithfulness", 2024, "Sample Conf. B", 22, "FaithExplain", "Explanation generation", ["MovieLens"], ["Faithfulness score"], "Single-turn settings only.", "we perturb inputs and check the explanation changes"],
  ["P11", "CritiqueRec: Critiquing-Based Conversational Recommendation", 2020, "Sample Conf. A", 88, "CritiqueRec", "Multi-turn dialogue", ["MovieLens", "Reddit-Movie"], ["Hit@10"], "No explanation component.", "users critique items and the system adapts"],
  ["P12", "LLM-Explain: Prompted Explanations for Conversational Recommendation", 2025, "Preprint", 9, "LLM-Explain", "Explanation generation; Multi-turn dialogue", ["Reddit-Movie"], ["Human rating"], "Not yet peer reviewed.", "a prompted language model explains each turn"],
];

export const PAPERS: PaperMeta[] = RAW.map(([id, title, year, venue, cit, , , , , , ], i) => ({
  paper_id: id, title, year, venue, citation_count: cit, pdf_url: null,
  abstract: `Sample abstract for ${title}. Replace with the real abstract from Semantic Scholar.`,
  found_by_query: ["explainable conversational recommender", "explanation generation recommendation dialogue", "multi-turn recommender dialogue"][i % 3],
}));

export const EXTRACTIONS: PaperExtraction[] = RAW.map(([id, , , , , method, problem, datasets, metrics, limitation, snippet]) => ({
  paper_id: id, extraction_mode: "abstract", problem, method_name: method,
  method_summary: `${method} — ${snippet}.`, datasets, baselines: [], metrics,
  results: "Improves over the listed baselines (sample).", limitations: [limitation], future_work: [],
  evidence_spans: { method_name: snippet, limitations: limitation }, status: id === "P08" ? "partial" : "ok",
}));

export const GAPS: Gap[] = [
  { gap_id: "gap-1", gap_type: "G3", subject_node_ids: ["run:Problem:explanation generation", "run:Problem:multi-turn dialogue"],
    stats: { n_a: 7, n_b: 6, n_joint: 2 }, supporting_paper_ids: ["P05", "P09", "P12", "P01", "P04"],
    claim: "7 papers study explanation generation and 6 study multi-turn dialogue, but only 2 study both together.",
    confidence: "medium", status: "accepted", round: 1 },
  { gap_id: "gap-2", gap_type: "G4", subject_node_ids: ["run:Problem:explanation generation", "run:MetricType:human evaluation"],
    stats: { n_papers: 7, n_with_type: 0 }, supporting_paper_ids: ["P01", "P02", "P03", "P07", "P10"],
    claim: "Of 7 papers on explanation generation, a majority never use human evaluation to judge explanation quality.",
    confidence: "medium", status: "accepted", round: 1 },
  { gap_id: "gap-3", gap_type: "G2", subject_node_ids: ["run:Method:kg-why", "run:Method:reviewgen"],
    stats: { shared_datasets: 1 }, supporting_paper_ids: ["P02", "P03"],
    claim: "KG-Why and ReviewGen share one dataset, but no paper compares them directly.",
    confidence: "low", status: "rejected", round: 1 },
  { gap_id: "gap-4", gap_type: "G1", subject_node_ids: ["run:Method:explainchat", "run:Dataset:reddit-movie"],
    stats: { n_datasets: 2, n_on_d: 4 }, supporting_paper_ids: ["P04", "P06", "P09", "P11", "P05"],
    claim: "ExplainChat was tested on 2 datasets but never on Reddit-Movie, which 4 other methods use.",
    confidence: "low", status: "accepted", round: 2 },
];

export const HYPOTHESES: Hypothesis[] = [
  { hyp_id: "hyp-1", gap_id: "gap-1", round: 1, status: "accepted",
    text: "A single model that plans dialogue turns and grounds each reply in retrieved evidence will give more trusted explanations than a pipeline that explains only after ranking.",
    rationale: "Joint papers add explanations after the dialogue model has decided; none plans for explanation.",
    grounding_node_ids: ["run:Problem:explanation generation", "run:Problem:multi-turn dialogue"],
    supporting_paper_ids: ["P05", "P09"], contradicting_paper_ids: ["P12"] },
  { hyp_id: "hyp-2", gap_id: "gap-1", round: 1, status: "rejected",
    text: "Explanations always improve recommendation accuracy in multi-turn settings.",
    rationale: "Too broad; no paper in the run measures accuracy change.",
    grounding_node_ids: ["run:Problem:multi-turn dialogue"], supporting_paper_ids: ["P05"], contradicting_paper_ids: [] },
  { hyp_id: "hyp-3", gap_id: "gap-2", round: 1, status: "accepted",
    text: "Explanation quality measured by human raters will rank methods differently from BLEU or ROUGE on the same outputs.",
    rationale: "Only P05 and P08 collect human judgements; the rest rely on text-overlap metrics.",
    grounding_node_ids: ["run:Problem:explanation generation"], supporting_paper_ids: ["P05", "P08"], contradicting_paper_ids: [] },
  { hyp_id: "hyp-4", gap_id: "gap-4", round: 2, status: "unresolved",
    text: "Retrieval-grounded explanations transfer to Reddit-style conversations without retraining the retriever.",
    rationale: "Reddit-Movie dialogues are less structured than the datasets ExplainChat used.",
    grounding_node_ids: ["run:Method:explainchat", "run:Dataset:reddit-movie"], supporting_paper_ids: ["P05", "P09"], contradicting_paper_ids: ["P06"] },
];

const ok = { is_real_gap: true, enough_support: true, evidence_chain_sound: true, not_already_published: true, entities_not_aliases: true };
export const VERDICTS: CriticVerdict[] = [
  { target_id: "gap-1", round: 1, checks: ok, verdict: "accept", reasons: ["Counts match the graph query.", "No paper found that already studies the combination."], required_changes: [] },
  { target_id: "gap-2", round: 1, checks: ok, verdict: "accept", reasons: ["Metric types were checked on every paper."], required_changes: [] },
  { target_id: "gap-3", round: 1, checks: { ...ok, entities_not_aliases: false }, verdict: "reject",
    reasons: ["“KG-Why” and “KG-Why model” were merged late; the pair is the same method."], required_changes: ["Drop this gap and use the next-ranked candidate."] },
  { target_id: "hyp-2", round: 1, checks: { ...ok, evidence_chain_sound: false, enough_support: false }, verdict: "reject",
    reasons: ["Cites one paper and none that measures accuracy change."], required_changes: ["Narrow the claim to what the cited papers measure."] },
  { target_id: "gap-4", round: 2, checks: ok, verdict: "accept", reasons: ["Replacement for gap-3."], required_changes: [] },
  { target_id: "hyp-1", round: 2, checks: ok, verdict: "accept", reasons: ["Supported by 2 papers; 1 contradicting paper is listed."], required_changes: [] },
  { target_id: "hyp-4", round: 3, checks: { ...ok, enough_support: false }, verdict: "reject",
    reasons: ["Only 2 supporting papers, one of which contradicts the transfer claim."], required_changes: ["Needs more evidence."] },
];

export const STATE: RunState = { papers: PAPERS, extractions: EXTRACTIONS, gaps: GAPS, hypotheses: HYPOTHESES, critic_verdicts: VERDICTS };

export const DIAGRAMS: Diagram[] = [
  { diagram_id: "d1", diagram_type: "concept_map", title: "How problems, methods and datasets relate", generation: "deterministic", syntax_valid: true, fully_grounded: true,
    report_slot: "literature_overview", status: "ok", source_node_ids: [], source_paper_ids: ["P01", "P02", "P04", "P05", "P09"],
    mermaid_source: `flowchart LR
  pe([Explanation generation]):::problem
  pd([Multi-turn dialogue]):::problem
  m1[TemplateTalk]:::method --> pe
  m2[KG-Why]:::method --> pe
  m3[ReviewGen]:::method --> pe
  m4[ReasonLM]:::method --> pe
  m5[ExplainChat]:::method --> pe
  m5 --> pd
  m6[UniConvRec]:::method --> pe
  m6 --> pd
  m7[DialogRec-Plan]:::method --> pd
  m8[CritiqueRec]:::method --> pd
  m1 -.-> d1[(MovieLens)]:::data
  m5 -.-> d1
  m5 -.-> d2[(Yelp)]:::data
  m7 -.-> d3[(Reddit-Movie)]:::data
  m6 -.-> d3
  classDef problem fill:#e4eafc,stroke:#2347d6,color:#0d1a2c
  classDef method fill:#ffffff,stroke:#44526a,color:#0d1a2c
  classDef data fill:#dff3ef,stroke:#0a8473,color:#0d1a2c` },
  { diagram_id: "d2", diagram_type: "timeline", title: "How the field developed", generation: "deterministic", syntax_valid: true, fully_grounded: true,
    report_slot: "literature_overview", status: "ok", source_node_ids: [], source_paper_ids: ["P01", "P02", "P04", "P05", "P07", "P10", "P12"],
    mermaid_source: `timeline
  title Publication years in this run
  2019 : TemplateTalk
  2020 : KG-Why : ReviewGen : CritiqueRec
  2021 : DialogRec-Plan : ConvBandit
  2022 : ExplainChat : Trust in the Loop
  2023 : ReasonLM : UniConvRec
  2024 : FaithExplain
  2025 : LLM-Explain` },
  { diagram_id: "d3", diagram_type: "comparison", title: "Retrieval-based vs generation-based explanations", generation: "llm", syntax_valid: true, fully_grounded: true,
    report_slot: "methods_datasets", status: "ok", source_node_ids: [], source_paper_ids: ["P02", "P05", "P03", "P07", "P12"],
    mermaid_source: `flowchart TB
  subgraph R[Retrieval-based]
    r1[KG-Why]
    r2[ExplainChat]
  end
  subgraph G[Generation-based]
    g1[ReviewGen]
    g2[ReasonLM]
    g3[LLM-Explain]
  end
  R --> a[Grounded in a source, easy to verify]
  G --> b[Fluent, but can drift from the model]` },
  { diagram_id: "d4", diagram_type: "architecture", title: "ExplainChat components and data flow", generation: "llm", syntax_valid: true, fully_grounded: true,
    report_slot: "architecture", status: "ok", source_node_ids: [], source_paper_ids: ["P05"],
    mermaid_source: `flowchart LR
  u[User turn] --> dm[Dialogue manager]
  dm --> rk[Ranker]
  rk --> rt[Evidence retriever]
  rt --> wr[Reply writer]
  wr --> o[Reply with explanation]` },
  { diagram_id: "d5", diagram_type: "sequence", title: "A multi-turn session", generation: "llm", syntax_valid: false, fully_grounded: false,
    report_slot: "architecture", status: "skipped", source_node_ids: [], source_paper_ids: [],
    skip_reason: "Only 5 of 8 full-text papers had component data, and none described turn-by-turn message flow.", mermaid_source: "" },
];

export const REPORT: Report = {
  uncited_sentence_count: 1,
  unresolved_items: ["hyp-4: needs more supporting papers (3 critic rounds used)"],
  sections: [
    { slot: "abstract", title: "Abstract", cited_paper_ids: ["P05", "P09"], markdown:
      "This report surveys 12 papers on explainable conversational recommender systems and finds 3 evidence-backed gaps. The strongest is that explanation generation and multi-turn dialogue are each well studied, yet only two papers combine them [@P05][@P09]." },
    { slot: "introduction", title: "Introduction", cited_paper_ids: ["P01", "P04"], markdown:
      "Conversational recommenders ask users questions across several turns before suggesting items [@P04]. Early explanation work used fixed templates [@P01].\n\nExplanations matter because users decide whether to trust a suggestion from the reason attached to it. [?]" },
    { slot: "literature_overview", title: "Literature overview", cited_paper_ids: ["P01", "P02", "P03", "P07", "P10", "P12"], markdown:
      "Explanation methods moved from templates [@P01] to knowledge-graph paths [@P02], then to text generated from reviews [@P03] and language models [@P07]. Recent work asks whether explanations are faithful to the model [@P10] and tests prompted models [@P12]." },
    { slot: "methods_datasets", title: "Methods and datasets", cited_paper_ids: ["P02", "P05", "P03", "P07"], markdown:
      "Methods split into two families. Retrieval-based methods ground each explanation in a source [@P02][@P05]. Generation-based methods write free text [@P03][@P07].\n\nMovieLens and Yelp are the most common datasets; Reddit-Movie appears mainly in dialogue papers." },
    { slot: "gaps", title: "Research gaps", cited_paper_ids: ["P05", "P09", "P01", "P03", "P07", "P10"], markdown:
      "- **Under-studied combination.** 7 papers study explanation generation and 6 study multi-turn dialogue, but only 2 study both [@P05][@P09]. Confidence: medium.\n- **Evaluation blind spot.** Most explanation papers rely on text-overlap metrics and skip human evaluation [@P01][@P03][@P07][@P10]. Confidence: medium.\n- **Untested pairing.** ExplainChat was never tested on Reddit-Movie [@P05]. Confidence: low." },
    { slot: "hypotheses", title: "Hypotheses", cited_paper_ids: ["P05", "P09", "P08", "P12"], markdown:
      "- A model that plans turns and grounds replies in evidence will earn more trust than one that explains after ranking [@P05][@P09]. One paper points the other way [@P12].\n- Human ratings of explanation quality will rank methods differently from BLEU or ROUGE [@P05][@P08]." },
    { slot: "architecture", title: "Architecture", cited_paper_ids: ["P05"], markdown:
      "The most complete architecture description comes from ExplainChat, where an evidence retriever sits between the ranker and the reply writer [@P05]." },
    { slot: "limitations", title: "Limitations and unresolved items", cited_paper_ids: [], markdown:
      "This run used abstracts for all papers except the 8 read in full for diagrams, so no gap is rated above medium confidence.\n\n- One hypothesis remains unresolved after 3 critic rounds (hyp-4).\n- The sequence diagram was skipped: not enough component data." },
  ],
};

export function buildEvidence(id: string): Evidence | null {
  const hyp = HYPOTHESES.find((h) => h.hyp_id === id);
  const gap = GAPS.find((g) => g.gap_id === (hyp ? hyp.gap_id : id));
  if (!gap) return null;
  const subj = gap.subject_node_ids.map((n) => {
    const [, type, name] = n.split(":");
    return { id: n, label: name, type: (type === "MetricType" ? "Metric" : type) as Evidence["nodes"][number]["type"], role: "subject" as const };
  });
  const papers = gap.supporting_paper_ids.map((p) => ({ id: p, label: p, type: "Paper" as const, role: "neighbour" as const }));
  const edges = gap.supporting_paper_ids.flatMap((p, i) => {
    const rel = gap.gap_type === "G4" ? "measured_by" : gap.gap_type === "G1" ? "evaluated_on" : "addresses";
    const targets = gap.gap_type === "G3" && i >= 2 ? [subj[i % 2]] : subj.slice(0, gap.gap_type === "G3" && i < 2 ? 2 : 1);
    return targets.map((t) => ({ source: p, target: t.id, rel }));
  });
  return { item_id: id, kind: hyp ? "hypothesis" : "gap", stats: gap.stats, paper_ids: gap.supporting_paper_ids, nodes: [...subj, ...papers], edges };
}
