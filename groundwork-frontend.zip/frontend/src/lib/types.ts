/** Mirrors Appendix A of the detailed design. Keep in sync with backend/app/models.py */

export type RunStatus = "queued" | "running" | "paused" | "completed" | "completed_with_warnings" | "failed";
export type StageId = "planner" | "discovery" | "understanding" | "graph" | "gap" | "hypothesis" | "critic" | "visualization" | "report";
export type StageStatus = "pending" | "running" | "done" | "warning" | "failed" | "skipped";
export type DiagramKind = "concept_map" | "architecture" | "comparison" | "timeline" | "sequence";
export type DiagramToggle = "auto" | "on" | "off";
export type ItemStatus = "candidate" | "accepted" | "rejected" | "unresolved";
export type Confidence = "low" | "medium" | "high";
export type GapTypeCode = "G1" | "G2" | "G3" | "G4";

export interface RunConfig {
  max_papers: number;
  max_search_rounds: number;
  max_critic_rounds: number;
  extraction_concurrency: number;
  fulltext_top_k: number;
  graph_node_cap_concept_map: number;
  min_papers_well_studied: number;
  min_methods_per_dataset: number;
  min_datasets_per_method: number;
  max_joint_papers: number;
  min_usable_papers: number;
  llm_call_budget: number;
  critic_enabled: boolean;        // ablation switch
  name_merging_enabled: boolean;  // ablation switch
  diagram_plan: Record<Exclude<DiagramKind, "concept_map">, DiagramToggle>;
}

export interface RunCounts {
  papers: number; usable: number; nodes: number; edges: number;
  merges: number; gaps: number; hypotheses: number; diagrams: number;
}
export interface Usage { llm_calls: number; budget: number; tokens: number; seconds: number }

export interface RunSummary {
  id: string;
  topic: string;
  status: RunStatus;
  created_at: string;
  config: RunConfig;
  stages: Record<StageId, StageStatus>;
  stage_notes: Partial<Record<StageId, string>>;
  critic_round: number;
  counts: RunCounts;
  usage: Usage;
  pause_reason?: string;
  fail_reason?: string;
}

export interface RunEvent {
  id: string;
  ts: string;
  stage: StageId;
  level: "info" | "warn" | "error";
  message: string;
}

export interface PaperMeta {
  paper_id: string;
  title: string;
  abstract: string | null;
  year: number | null;
  venue: string | null;
  citation_count: number;
  pdf_url?: string | null;
  found_by_query: string;
}

export interface PaperExtraction {
  paper_id: string;
  extraction_mode: "abstract" | "fulltext";
  problem: string | null;
  method_name: string | null;
  method_summary: string | null;
  datasets: string[];
  baselines: string[];
  metrics: string[];
  results: string | null;
  limitations: string[];
  future_work: string[];
  evidence_spans: Record<string, string>;
  status: "ok" | "partial" | "failed";
}

export interface Gap {
  gap_id: string;
  gap_type: GapTypeCode;
  subject_node_ids: string[];
  stats: Record<string, number>;
  supporting_paper_ids: string[];
  claim: string;
  confidence: Confidence;
  status: ItemStatus;
  round: number;
}

export interface Hypothesis {
  hyp_id: string;
  gap_id: string;
  text: string;
  rationale: string;
  grounding_node_ids: string[];
  supporting_paper_ids: string[];
  contradicting_paper_ids: string[];
  status: ItemStatus;
  round: number;
}

export type CriticCheck = "is_real_gap" | "enough_support" | "evidence_chain_sound" | "not_already_published" | "entities_not_aliases";
export interface CriticVerdict {
  target_id: string;
  round: number;
  checks: Record<CriticCheck, boolean>;
  verdict: "accept" | "reject";
  reasons: string[];
  required_changes: string[];
}

export interface Diagram {
  diagram_id: string;
  diagram_type: DiagramKind;
  title: string;
  generation: "deterministic" | "llm";
  mermaid_source: string;
  source_node_ids: string[];
  source_paper_ids: string[];
  syntax_valid: boolean;
  fully_grounded: boolean;
  report_slot: string;
  status: "ok" | "skipped" | "failed";
  skip_reason?: string | null;
}

export interface ReportSection { slot: string; title: string; markdown: string; cited_paper_ids: string[] }
export interface Report { sections: ReportSection[]; uncited_sentence_count: number; unresolved_items: string[] }

/** GET /runs/{id}/state — everything the Evidence and Rating screens need */
export interface RunState {
  papers: PaperMeta[];
  extractions: PaperExtraction[];
  gaps: Gap[];
  hypotheses: Hypothesis[];
  critic_verdicts: CriticVerdict[];
}

export type GraphNodeType = "Paper" | "Method" | "Problem" | "Dataset" | "Metric" | "Limitation" | "Component";
export interface GraphNodeView { id: string; label: string; type: GraphNodeType; role?: "subject" | "neighbour" }
export interface GraphEdgeView { source: string; target: string; rel: string }
export interface Evidence {
  item_id: string;
  kind: "gap" | "hypothesis";
  stats: Record<string, number>;
  paper_ids: string[];
  nodes: GraphNodeView[];
  edges: GraphEdgeView[];
}

export type RatingLabel = "real" | "plausible" | "hallucinated";
export interface Rating { target_id: string; kind: "gap" | "hypothesis"; label: RatingLabel; rater: string; note?: string }
