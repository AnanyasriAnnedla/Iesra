/** Time-based run simulator: survives page reloads because state is computed from elapsed time. */
import { DIAGRAMS, REPORT, STATE, buildEvidence } from "./mock-data";
import type { RunConfig, RunCounts, RunEvent, RunStatus, RunSummary, StageId, StageStatus, Usage, Rating } from "./types";

type Level = "info" | "warn" | "error";
interface Step { at: number; stage: StageId; level?: Level; message: string; status?: StageStatus; note?: string; critic_round?: number; counts?: Partial<RunCounts>; usage?: Partial<Usage> }
type Scenario = "normal" | "pause" | "fail";
interface Rec { id: string; topic: string; config: RunConfig; t0: number; scenario: Scenario }

const S = (at: number, stage: StageId, message: string, o: Partial<Step> = {}): Step => ({ at, stage, message, ...o });
const SCHEDULE: Step[] = [
  S(0, "planner", "Splitting the topic into sub-questions", { status: "running" }),
  S(1200, "planner", "5 sub-questions, 6 search queries. Diagrams planned: concept map, timeline, comparison, architecture", { status: "done", usage: { llm_calls: 2, tokens: 3100 } }),
  S(1300, "discovery", "Searching Semantic Scholar and arXiv", { status: "running" }),
  S(2000, "discovery", "Round 1: 7 relevant papers found", { counts: { papers: 7 }, usage: { llm_calls: 3, tokens: 7200 } }),
  S(3200, "discovery", "Round 2: 4 new papers from sharper queries", { counts: { papers: 11 }, usage: { llm_calls: 4, tokens: 11000 } }),
  S(4200, "discovery", "Round 3: 1 new paper (fewer than 3), so search stops", { counts: { papers: 12 }, usage: { llm_calls: 5, tokens: 14400 } }),
  S(4400, "discovery", "12 papers kept, 0 dropped for missing abstracts", { status: "done" }),
  S(4500, "understanding", "Reading abstracts, 8 at a time", { status: "running" }),
  S(5400, "understanding", "8 of 12 fact sheets done", { usage: { llm_calls: 13, tokens: 31000 } }),
  S(6400, "understanding", "12 of 12 fact sheets done", { usage: { llm_calls: 17, tokens: 44800 } }),
  S(6700, "understanding", "P08 failed the layout check twice and is marked partial", { level: "warn" }),
  S(7000, "understanding", "11 usable papers (minimum 10)", { status: "warning", counts: { usable: 11 } }),
  S(7100, "graph", "Building the knowledge graph", { status: "running" }),
  S(7900, "graph", "Merged 9 aliases (merge log saved)", { counts: { merges: 9 }, usage: { llm_calls: 19, tokens: 49000 } }),
  S(8600, "graph", "Sanity checks passed: every paper is connected", { counts: { nodes: 64, edges: 131 } }),
  S(8800, "graph", "Graph ready. Starting both branches", { status: "done" }),
  S(8900, "gap", "Running the four gap searches", { status: "running" }),
  S(8900, "visualization", "Reading full text of the top 8 papers", { status: "running" }),
  S(9900, "gap", "4 candidate gaps ranked", { status: "done", counts: { gaps: 4 }, usage: { llm_calls: 22, tokens: 55000 } }),
  S(10000, "hypothesis", "Writing 2 to 3 hypotheses per gap", { status: "running" }),
  S(10600, "visualization", "Concept map and timeline built from the graph", { counts: { diagrams: 2 } }),
  S(11200, "hypothesis", "4 hypotheses written, all cite graph items", { status: "done", counts: { hypotheses: 4 }, usage: { llm_calls: 27, tokens: 66000 } }),
  S(11300, "critic", "Round 1: reviewing 4 gaps and 4 hypotheses", { status: "running", critic_round: 1 }),
  S(11800, "visualization", "Components found in 5 of 8 papers", { usage: { llm_calls: 34, tokens: 90000 } }),
  S(12600, "critic", "Round 1: rejected gap-3 (aliases) and hyp-2 (weak evidence)", { level: "warn", usage: { llm_calls: 38, tokens: 99000 } }),
  S(12700, "gap", "Replacing gap-3 with the next-ranked candidate", { status: "running" }),
  S(13100, "visualization", "Sequence diagram skipped: no turn-by-turn data", { level: "warn", counts: { diagrams: 4 } }),
  S(13300, "visualization", "4 diagrams ready, 1 skipped", { status: "warning" }),
  S(13400, "gap", "Replacement gap found", { status: "done" }),
  S(13500, "hypothesis", "Retrying hyp-2 with the critic's feedback", { status: "running" }),
  S(14200, "hypothesis", "Revised hypotheses written", { status: "done", usage: { llm_calls: 43, tokens: 112000 } }),
  S(14300, "critic", "Round 2: accepted 3 gaps, 2 hypotheses", { critic_round: 2, usage: { llm_calls: 47, tokens: 120000 } }),
  S(15000, "critic", "Round 3: hyp-4 still lacks support and is marked unresolved", { level: "warn", critic_round: 3, status: "done", usage: { llm_calls: 49, tokens: 126000 } }),
  S(15100, "report", "Both branches finished. Writing the report", { status: "running" }),
  S(16400, "report", "Checking that every claim sentence has a citation", { usage: { llm_calls: 58, tokens: 150000 } }),
  S(16900, "report", "1 sentence has no citation and is flagged in the report", { level: "warn" }),
  S(17200, "report", "Report ready", { status: "warning", usage: { llm_calls: 60, tokens: 154000 } }),
];
const END = 17200;
const PAUSE_AT = 5700, FAIL_AT = 4500;
const PAUSE_STEP = S(PAUSE_AT, "understanding", "LLM-call budget reached. Run paused with progress saved", { level: "warn", usage: { llm_calls: 24, tokens: 62000 } });
const FAIL_STEP = S(FAIL_AT, "discovery", "Only 6 usable papers found (minimum 10). Try a broader topic", { level: "error", status: "failed", counts: { papers: 6, usable: 6 } });

const ALL: StageId[] = ["planner", "discovery", "understanding", "graph", "gap", "hypothesis", "critic", "visualization", "report"];
const KEY = "gw.mock.runs";
export const DEFAULT_CONFIG: RunConfig = {
  max_papers: 30, max_search_rounds: 4, max_critic_rounds: 3, extraction_concurrency: 8, fulltext_top_k: 8,
  graph_node_cap_concept_map: 25, min_papers_well_studied: 5, min_methods_per_dataset: 3, min_datasets_per_method: 2,
  max_joint_papers: 2, min_usable_papers: 10, llm_call_budget: 400, critic_enabled: true, name_merging_enabled: true,
  diagram_plan: { timeline: "auto", comparison: "auto", architecture: "auto", sequence: "auto" },
};

function load(): Rec[] {
  try { const r = localStorage.getItem(KEY); if (r) return JSON.parse(r); } catch {}
  const old = Date.now() - 86_400_000;
  const seed: Rec[] = [
    { id: "run-demo01", topic: "Explainable conversational recommender systems", config: DEFAULT_CONFIG, t0: old, scenario: "normal" },
    { id: "run-demo02", topic: "Federated learning for rare disease imaging", config: DEFAULT_CONFIG, t0: old - 3_600_000, scenario: "fail" },
    { id: "run-demo03", topic: "Graph neural networks for course recommendation", config: DEFAULT_CONFIG, t0: old - 7_200_000, scenario: "pause" },
  ];
  save(seed); return seed;
}
function save(r: Rec[]) { try { localStorage.setItem(KEY, JSON.stringify(r)); } catch {} }

function plan(r: Rec): Step[] {
  if (r.scenario === "fail") return [...SCHEDULE.filter((s) => s.at < FAIL_AT), FAIL_STEP];
  if (r.scenario === "pause") return [...SCHEDULE.filter((s) => s.at < PAUSE_AT), PAUSE_STEP];
  return SCHEDULE;
}

function build(r: Rec, now = Date.now()) {
  const el = now - r.t0;
  const steps = plan(r).filter((s) => s.at <= el);
  const stages = Object.fromEntries(ALL.map((s) => [s, "pending"])) as Record<StageId, StageStatus>;
  const notes: RunSummary["stage_notes"] = {};
  const counts: RunCounts = { papers: 0, usable: 0, nodes: 0, edges: 0, merges: 0, gaps: 0, hypotheses: 0, diagrams: 0 };
  const usage: Usage = { llm_calls: 0, budget: r.config.llm_call_budget, tokens: 0, seconds: Math.min(el, END) / 1000 };
  let round = 0;
  const events: RunEvent[] = steps.map((s, i) => {
    if (s.status) stages[s.stage] = s.status;
    if (s.status === "running" && s.stage === "gap" && round > 0) stages.gap = "running";
    notes[s.stage] = s.message;
    if (s.critic_round !== undefined) round = s.critic_round;
    Object.assign(counts, s.counts); Object.assign(usage, s.usage);
    return { id: `${r.id}-${i}`, ts: new Date(r.t0 + s.at).toISOString(), stage: s.stage, level: s.level ?? "info", message: s.message };
  });
  let status: RunStatus = el < 300 ? "queued" : "running";
  let pause_reason: string | undefined, fail_reason: string | undefined;
  if (r.scenario === "fail" && el >= FAIL_AT) { status = "failed"; fail_reason = FAIL_STEP.message; }
  else if (r.scenario === "pause" && el >= PAUSE_AT) { status = "paused"; pause_reason = PAUSE_STEP.message; }
  else if (r.scenario === "normal" && el >= END) status = "completed_with_warnings";
  return { events, summary: { id: r.id, topic: r.topic, status, created_at: new Date(r.t0).toISOString(), config: r.config, stages, stage_notes: notes, critic_round: round, counts, usage, pause_reason, fail_reason } as RunSummary };
}

const delay = <T,>(v: T, ms = 120) => new Promise<T>((res) => setTimeout(() => res(v), ms));

export const mockApi = {
  listRuns: async () => delay(load().map((r) => build(r).summary).sort((a, b) => b.created_at.localeCompare(a.created_at))),
  getRun: async (id: string) => {
    const r = load().find((x) => x.id === id);
    if (!r) throw new Error("Run not found");
    return delay(build(r).summary, 60);
  },
  createRun: async (topic: string, config: RunConfig) => {
    const t = topic.toLowerCase();
    const rec: Rec = { id: `run-${Math.random().toString(36).slice(2, 8)}`, topic, config, t0: Date.now(), scenario: t.includes("fail") ? "fail" : t.includes("pause") ? "pause" : "normal" };
    save([...load(), rec]);
    return delay({ id: rec.id });
  },
  resumeRun: async (id: string) => {
    const all = load(); const r = all.find((x) => x.id === id);
    if (r) { r.scenario = "normal"; r.t0 = Date.now() - PAUSE_AT; save(all); }
    return delay(undefined);
  },
  streamEvents: (id: string, onEvent: (e: RunEvent) => void) => {
    const seen = new Set<string>();
    const tick = () => {
      const r = load().find((x) => x.id === id); if (!r) return;
      build(r).events.forEach((e) => { if (!seen.has(e.id)) { seen.add(e.id); onEvent(e); } });
    };
    tick(); const h = setInterval(tick, 600);
    return () => clearInterval(h);
  },
  getReport: async (_id: string) => delay(REPORT),
  getDiagrams: async (_id: string) => delay(DIAGRAMS),
  getState: async (_id: string) => delay(STATE),
  getEvidence: async (_id: string, item: string) => delay(buildEvidence(item)),
  listRatings: async (id: string): Promise<Rating[]> => { try { return JSON.parse(localStorage.getItem(`gw.ratings.${id}`) ?? "[]"); } catch { return []; } },
  postRating: async (id: string, rating: Rating) => {
    const cur = await mockApi.listRatings(id);
    const next = [...cur.filter((x) => !(x.target_id === rating.target_id && x.rater === rating.rater)), rating];
    localStorage.setItem(`gw.ratings.${id}`, JSON.stringify(next));
  },
};
