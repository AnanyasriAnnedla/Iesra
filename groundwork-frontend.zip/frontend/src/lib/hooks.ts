"use client";
import { createContext, useCallback, useContext, useEffect, useRef, useState } from "react";
import { api } from "./api";
import { isTerminal } from "./utils";
import type { RunEvent, RunSummary } from "./types";

export function useAsync<T>(fn: () => Promise<T>, deps: unknown[]) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const run = useCallback(() => {
    setLoading(true);
    fn().then((d) => { setData(d); setError(null); }).catch((e) => setError(e.message ?? "Request failed")).finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  useEffect(run, [run]);
  return { data, error, loading, reload: run };
}

export function useRunPolling(id: string) {
  const [run, setRun] = useState<RunSummary | null>(null);
  const [error, setError] = useState<string | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout>>();
  const fetchOnce = useCallback(async () => {
    try { const r = await api.getRun(id); setRun(r); setError(null); return r; }
    catch (e) { setError((e as Error).message); return null; }
  }, [id]);
  useEffect(() => {
    let stop = false;
    const loop = async () => {
      const r = await fetchOnce();
      if (stop) return;
      if (!r || !isTerminal(r.status)) timer.current = setTimeout(loop, r?.status === "paused" ? 4000 : 1200);
    };
    loop();
    return () => { stop = true; clearTimeout(timer.current); };
  }, [fetchOnce]);
  return { run, error, refresh: fetchOnce };
}

export function useRunEvents(id: string) {
  const [events, setEvents] = useState<RunEvent[]>([]);
  useEffect(() => {
    setEvents([]);
    return api.streamEvents(id, (e) => setEvents((prev) => (prev.some((p) => p.id === e.id) ? prev : [...prev, e])));
  }, [id]);
  return events;
}

export const RunContext = createContext<{ run: RunSummary; refresh: () => Promise<unknown> } | null>(null);
export const useRun = () => {
  const c = useContext(RunContext);
  if (!c) throw new Error("useRun must be used inside a run layout");
  return c;
};
