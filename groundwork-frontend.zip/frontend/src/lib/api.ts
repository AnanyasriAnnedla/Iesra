import { DEFAULT_CONFIG, mockApi } from "./mock";
import type { Diagram, Evidence, Rating, Report, RunConfig, RunEvent, RunState, RunSummary } from "./types";

export const USE_MOCK = process.env.NEXT_PUBLIC_USE_MOCK !== "false";
const BASE = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";
export { DEFAULT_CONFIG };

export class ApiError extends Error {
  constructor(public status: number, message: string) { super(message); }
}
async function http<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, { ...init, headers: { "Content-Type": "application/json", ...init?.headers }, cache: "no-store" });
  if (!res.ok) throw new ApiError(res.status, (await res.text().catch(() => "")) || res.statusText);
  return res.status === 204 ? (undefined as T) : res.json();
}

/** Contract = design doc section 6 (+ GET /runs/{id}/state and GET /runs/{id}/ratings, see README). */
const live = {
  listRuns: () => http<RunSummary[]>("/runs"),
  getRun: (id: string) => http<RunSummary>(`/runs/${id}`),
  createRun: (topic: string, config: RunConfig) => http<{ id: string }>("/runs", { method: "POST", body: JSON.stringify({ topic, config }) }),
  resumeRun: (id: string) => http<void>(`/runs/${id}/resume`, { method: "POST" }),
  streamEvents: (id: string, onEvent: (e: RunEvent) => void) => {
    const es = new EventSource(`${BASE}/runs/${id}/events`);
    es.onmessage = (m) => { try { onEvent(JSON.parse(m.data)); } catch {} };
    return () => es.close();
  },
  getReport: (id: string) => http<Report>(`/runs/${id}/report`),
  getDiagrams: (id: string) => http<Diagram[]>(`/runs/${id}/diagrams`),
  getState: (id: string) => http<RunState>(`/runs/${id}/state`),
  getEvidence: (id: string, item: string) => http<Evidence | null>(`/runs/${id}/evidence/${encodeURIComponent(item)}`),
  listRatings: (id: string) => http<Rating[]>(`/runs/${id}/ratings`),
  postRating: (id: string, r: Rating) => http<void>(`/runs/${id}/ratings`, { method: "POST", body: JSON.stringify(r) }),
};

export const api: typeof live = USE_MOCK ? (mockApi as unknown as typeof live) : live;
