import clsx, { type ClassValue } from "clsx";
import type { GapTypeCode, RunStatus, StageId } from "./types";

export const cn = (...a: ClassValue[]) => clsx(a);

export const fmtDate = (iso: string) =>
  new Date(iso).toLocaleString(undefined, { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
export const fmtTime = (iso: string) =>
  new Date(iso).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false });
export const fmtDuration = (s: number) => (s < 60 ? `${Math.round(s)}s` : `${Math.floor(s / 60)}m ${Math.round(s % 60)}s`);
export const fmtNum = (n: number) => (n >= 1000 ? `${(n / 1000).toFixed(1)}k` : String(n));

export const STATUS_LABEL: Record<RunStatus, string> = {
  queued: "Queued", running: "Running", paused: "Paused",
  completed: "Completed", completed_with_warnings: "Completed with warnings", failed: "Failed",
};
export const isTerminal = (s: RunStatus) => s === "completed" || s === "completed_with_warnings" || s === "failed";
export const hasReport = (s: RunStatus) => s === "completed" || s === "completed_with_warnings";

export const STAGE_LABEL: Record<StageId, string> = {
  planner: "Planner", discovery: "Literature discovery", understanding: "Paper understanding",
  graph: "Knowledge graph", gap: "Gap discovery", hypothesis: "Hypotheses", critic: "Critic",
  visualization: "Visualization", report: "Report",
};

export const GAP_TYPE_LABEL: Record<GapTypeCode, { name: string; plain: string }> = {
  G1: { name: "Untested pairing", plain: "A method has never been tried on a dataset many other methods use." },
  G2: { name: "Never compared", plain: "Two methods share a dataset but no paper compares them directly." },
  G3: { name: "Under-studied combination", plain: "Two well-studied problems are rarely studied together." },
  G4: { name: "Evaluation blind spot", plain: "A well-studied problem is never measured in a certain way." },
};

export function paragraphsOf(md: string) {
  return md.split(/\n{2,}/).map((p) => p.trim()).filter(Boolean);
}
export function download(name: string, text: string, type = "text/plain") {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const a = document.createElement("a");
  a.href = url; a.download = name; a.click();
  URL.revokeObjectURL(url);
}
