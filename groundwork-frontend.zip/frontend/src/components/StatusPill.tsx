import { AlertTriangle, CheckCircle2, CircleDashed, Loader2, PauseCircle, XCircle } from "lucide-react";
import type { RunStatus } from "@/lib/types";
import { STATUS_LABEL, cn } from "@/lib/utils";

const STYLE: Record<RunStatus, { cls: string; Icon: typeof Loader2 }> = {
  queued: { cls: "bg-sunken text-mute", Icon: CircleDashed },
  running: { cls: "bg-reason-tint text-reason", Icon: Loader2 },
  paused: { cls: "bg-warn-tint text-warn", Icon: PauseCircle },
  completed: { cls: "bg-ok-tint text-ok", Icon: CheckCircle2 },
  completed_with_warnings: { cls: "bg-warn-tint text-warn", Icon: AlertTriangle },
  failed: { cls: "bg-bad-tint text-bad", Icon: XCircle },
};
export function StatusPill({ status }: { status: RunStatus }) {
  const { cls, Icon } = STYLE[status];
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium", cls)}>
      <Icon size={13} aria-hidden className={status === "running" ? "animate-spin motion-reduce:animate-none" : ""} />
      {STATUS_LABEL[status]}
    </span>
  );
}
