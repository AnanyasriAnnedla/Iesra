"use client";
import type { Evidence } from "@/lib/types";

const TYPE_COLOR: Record<string, string> = { Paper: "var(--ink-2)", Method: "var(--reason)", Problem: "var(--reason)", Dataset: "var(--viz)", Metric: "var(--warn)", Limitation: "var(--bad)", Component: "var(--viz)" };

export function GraphNeighborhood({ evidence, onPaper }: { evidence: Evidence; onPaper: (id: string) => void }) {
  const subjects = evidence.nodes.filter((n) => n.role === "subject");
  const others = evidence.nodes.filter((n) => n.role !== "subject");
  const W = 640, H = 360, cx = W / 2, cy = H / 2;
  const pos = new Map<string, { x: number; y: number }>();
  subjects.forEach((n, i) => pos.set(n.id, { x: cx + (i - (subjects.length - 1) / 2) * 200, y: cy }));
  others.forEach((n, i) => {
    const a = (Math.PI * 2 * i) / others.length - Math.PI / 2;
    pos.set(n.id, { x: cx + Math.cos(a) * 250, y: cy + Math.sin(a) * 140 });
  });
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label={`Graph neighbourhood: ${subjects.map((s) => s.label).join(" and ")} with ${others.length} connected items`}>
      {evidence.edges.map((e, i) => {
        const a = pos.get(e.source), b = pos.get(e.target); if (!a || !b) return null;
        return (
          <g key={i}>
            <line x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke="var(--line)" strokeWidth={1.5} />
            <text x={(a.x + b.x) / 2} y={(a.y + b.y) / 2 - 3} fontSize="10" textAnchor="middle" fill="var(--ink-3)">{e.rel.replace("_", " ")}</text>
          </g>
        );
      })}
      {evidence.nodes.map((n) => {
        const p = pos.get(n.id); if (!p) return null;
        const subj = n.role === "subject"; const c = TYPE_COLOR[n.type] ?? "var(--ink-2)";
        const w = subj ? Math.max(96, n.label.length * 7.4 + 24) : 48;
        const g = (
          <g key={n.id} transform={`translate(${p.x} ${p.y})`} className={!subj ? "cursor-pointer" : ""}>
            <rect x={-w / 2} y={-16} width={w} height={32} rx={subj ? 16 : 8} fill="var(--surface)" stroke={c} strokeWidth={subj ? 2.2 : 1.4} />
            <text textAnchor="middle" y={4.5} fontSize={subj ? 12.5 : 11.5} fontWeight={subj ? 600 : 500} fill="var(--ink)">{n.label}</text>
          </g>
        );
        return subj ? g : (
          <g key={n.id} role="button" tabIndex={0} aria-label={`Open paper ${n.label}`} onClick={() => onPaper(n.id)} onKeyDown={(e) => e.key === "Enter" && onPaper(n.id)}>{g}</g>
        );
      })}
    </svg>
  );
}
