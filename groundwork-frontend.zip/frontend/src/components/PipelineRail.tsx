"use client";
import type { RunSummary, StageId, StageStatus } from "@/lib/types";
import { STAGE_LABEL, cn } from "@/lib/utils";

type Lane = "main" | "reason" | "viz";
const W = 116, H = 46;
const Y = { reason: 64, main: 140, viz: 216 };
const NODES: { id: StageId; x: number; lane: Lane }[] = [
  { id: "planner", x: 62, lane: "main" }, { id: "discovery", x: 192, lane: "main" },
  { id: "understanding", x: 322, lane: "main" }, { id: "graph", x: 452, lane: "main" },
  { id: "gap", x: 604, lane: "reason" }, { id: "hypothesis", x: 734, lane: "reason" }, { id: "critic", x: 864, lane: "reason" },
  { id: "visualization", x: 734, lane: "viz" }, { id: "report", x: 1000, lane: "main" },
];
const pos = (id: StageId) => { const n = NODES.find((n) => n.id === id)!; return { ...n, y: Y[n.lane] }; };
const laneColor = (l: Lane) => (l === "reason" ? "var(--reason)" : l === "viz" ? "var(--viz)" : "var(--ink)");

const EDGES: { from: StageId; to: StageId; d: string; lane: Lane }[] = [
  { from: "planner", to: "discovery", d: "M120 140H134", lane: "main" },
  { from: "discovery", to: "understanding", d: "M250 140H264", lane: "main" },
  { from: "understanding", to: "graph", d: "M380 140H394", lane: "main" },
  { from: "graph", to: "gap", d: "M510 140C556 140 548 64 546 64", lane: "reason" },
  { from: "graph", to: "visualization", d: "M510 140C556 140 560 216 676 216", lane: "viz" },
  { from: "gap", to: "hypothesis", d: "M662 64H676", lane: "reason" },
  { from: "hypothesis", to: "critic", d: "M792 64H806", lane: "reason" },
  { from: "critic", to: "report", d: "M922 64C960 64 924 140 942 140", lane: "reason" },
  { from: "visualization", to: "report", d: "M792 216H900C930 216 920 140 942 140", lane: "viz" },
];

function Glyph({ s, color }: { s: StageStatus; color: string }) {
  const c = { fill: "none", strokeWidth: 2, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
  if (s === "done") return <path d="M-4 0l3 3 6-6" stroke={color} {...c} />;
  if (s === "warning") return <path d="M0-5v6M0 4v.1" stroke="var(--warn)" {...c} />;
  if (s === "failed") return <path d="M-4-4l8 8M4-4l-8 8" stroke="var(--bad)" {...c} />;
  if (s === "skipped") return <path d="M-4 0h8" stroke="var(--ink-3)" {...c} />;
  if (s === "running") return <circle r="3" fill={color} />;
  return <circle r="3" stroke="var(--ink-3)" {...c} />;
}

export function PipelineRail({ run, selected, onSelect }: { run: RunSummary; selected: StageId | null; onSelect: (s: StageId | null) => void }) {
  const st = run.stages;
  const live = (id: StageId) => st[id] === "running";
  const active = (e: (typeof EDGES)[number]) => live(e.to) || (st[e.from] === "done" && live(e.to));
  const reached = (e: (typeof EDGES)[number]) => st[e.from] !== "pending" && st[e.to] !== "pending";
  const loopOn = run.critic_round > 0 && run.config.critic_enabled;
  return (
    <figure className="m-0">
      <svg viewBox="0 0 1060 262" className="w-full min-w-[680px]" role="group" aria-label="Pipeline progress">
        <defs>
          <marker id="ah" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0L8 4L0 8z" fill="context-stroke" /></marker>
        </defs>
        {EDGES.map((e) => (
          <path key={e.from + e.to} d={e.d} fill="none" stroke={reached(e) ? laneColor(e.lane) : "var(--line)"} strokeWidth={2}
            markerEnd="url(#ah)" className={active(e) ? "edge-live" : ""} opacity={reached(e) ? 1 : 0.9} />
        ))}
        {run.config.critic_enabled && (
          <g>
            <path d="M864 41C864 4 604 4 604 41" fill="none" stroke={loopOn ? "var(--reason)" : "var(--line)"} strokeWidth={2} strokeDasharray="2 5" strokeLinecap="round" markerEnd="url(#ah)" />
            <text x="734" y="17" textAnchor="middle" fontSize="12" fill="var(--ink-2)">
              {loopOn ? `Critic round ${run.critic_round} of ${run.config.max_critic_rounds}` : `Critic loop, up to ${run.config.max_critic_rounds} rounds`}
            </text>
          </g>
        )}
        {!run.config.critic_enabled && <text x="734" y="17" textAnchor="middle" fontSize="12" fill="var(--warn)">Critic off for this run (ablation)</text>}
        <text x="540" y="256" fontSize="12" fill="var(--ink-2)">Both branches run at the same time and join before the report.</text>
        {NODES.map(({ id }) => {
          const n = pos(id); const s = st[id]; const color = laneColor(n.lane);
          const x = n.x - W / 2, y = n.y - H / 2; const isSel = selected === id;
          const note = run.stage_notes[id];
          return (
            <g key={id} role="button" tabIndex={0} aria-pressed={isSel} aria-label={`${STAGE_LABEL[id]}: ${s}. ${note ?? ""}`}
              onClick={() => onSelect(isSel ? null : id)} onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && (e.preventDefault(), onSelect(isSel ? null : id))} className="cursor-pointer outline-none [&:focus-visible>rect:last-of-type]:stroke-[var(--reason)]">
              {s === "running" && <rect x={x - 4} y={y - 4} width={W + 8} height={H + 8} rx={13} fill="none" stroke={color} strokeWidth={2} className="node-pulse" />}
              <rect x={x} y={y} width={W} height={H} rx={10}
                fill={s === "done" ? "var(--surface)" : s === "pending" ? "var(--sunken)" : "var(--surface)"}
                stroke={s === "failed" ? "var(--bad)" : s === "warning" ? "var(--warn)" : s === "pending" ? "var(--line)" : color} strokeWidth={isSel ? 2.5 : 1.5} />
              <g transform={`translate(${x + 16} ${n.y})`}><Glyph s={s} color={color} /></g>
              <text x={x + 30} y={n.y + 4.5} fontSize="12.5" fontWeight={500} fill={s === "pending" ? "var(--ink-3)" : "var(--ink)"}>
                {id === "understanding" ? "Understanding" : id === "visualization" ? "Visualization" : id === "discovery" ? "Discovery" : STAGE_LABEL[id]}
              </text>
              <rect x={x} y={y} width={W} height={H} rx={10} fill="none" stroke="transparent" strokeWidth={2.5} />
            </g>
          );
        })}
      </svg>
      <figcaption className="sr-only">Planner, discovery, understanding and graph run in order. Then gap, hypothesis and critic run beside visualization. Both finish before the report.</figcaption>
    </figure>
  );
}
