import { BadgeCheck, ExternalLink } from "lucide-react";
import type { PaperExtraction, PaperMeta } from "@/lib/types";

const FIELDS: [keyof PaperExtraction, string][] = [
  ["problem", "Problem"], ["method_name", "Method"], ["datasets", "Datasets"], ["metrics", "Metrics"], ["limitations", "Limitations"],
];
export function SourcePanel({ paper, extraction, onClose }: { paper: PaperMeta; extraction?: PaperExtraction; onClose?: () => void }) {
  return (
    <div className="rounded-md border border-line bg-surface p-4">
      <div className="flex items-start justify-between gap-3">
        <p className="tabnum rounded bg-reason-tint px-1.5 py-0.5 text-xs font-semibold text-reason">{paper.paper_id}</p>
        {onClose && <button className="text-xs text-mute underline" onClick={onClose}>Close</button>}
      </div>
      <h3 className="mt-2 font-serif text-lg font-semibold leading-snug">{paper.title}</h3>
      <p className="hint mt-1">{[paper.venue, paper.year, `${paper.citation_count} citations`].filter(Boolean).join(", ")}</p>
      <p className="hint mt-1">Found by: “{paper.found_by_query}”</p>
      {paper.pdf_url && <a href={paper.pdf_url} target="_blank" rel="noreferrer" className="mt-2 inline-flex items-center gap-1 text-sm text-reason underline">Open paper <ExternalLink size={13} /></a>}
      {extraction && (
        <dl className="mt-4 space-y-3 border-t border-line pt-3 text-sm">
          {FIELDS.map(([k, label]) => {
            const v = extraction[k]; const text = Array.isArray(v) ? v.join(", ") : (v as string | null);
            if (!text) return null;
            const snip = extraction.evidence_spans[k as string];
            return (
              <div key={k}>
                <dt className="text-xs font-medium text-mute">{label}</dt>
                <dd>{text}</dd>
                {snip && <dd className="mt-1 flex gap-1.5 text-[13px] italic text-mute"><BadgeCheck size={14} className="mt-0.5 shrink-0 text-ok" aria-label="Snippet verified in the abstract" />“{snip}”</dd>}
              </div>
            );
          })}
          {extraction.status !== "ok" && <p className="rounded bg-warn-tint px-2 py-1 text-xs text-warn">Fact sheet is {extraction.status}; this paper is left out of the graph.</p>}
        </dl>
      )}
    </div>
  );
}
