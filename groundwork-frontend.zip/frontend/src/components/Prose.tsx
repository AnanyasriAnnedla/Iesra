"use client";
import { Fragment } from "react";
import { paragraphsOf } from "@/lib/utils";

const TOKEN = /(\[@[^\]]+\]|\[\?\]|\*\*[^*]+\*\*)/g;

function Inline({ text, onCite, active }: { text: string; onCite: (id: string) => void; active: string | null }) {
  return (
    <>
      {text.split(TOKEN).map((part, i) => {
        if (part === "[?]") return <span key={i} className="uncited rounded-sm bg-warn-tint px-1 font-sans text-[11px] font-semibold text-warn" title="No paper citation found for this sentence">needs citation</span>;
        if (part.startsWith("[@")) { const id = part.slice(2, -1); return <button key={i} className="cite" aria-pressed={active === id} aria-label={`Source ${id}`} onClick={() => onCite(id)}>{id}</button>; }
        if (part.startsWith("**")) return <strong key={i}>{part.slice(2, -2)}</strong>;
        return <Fragment key={i}>{part}</Fragment>;
      })}
    </>
  );
}

export function Prose({ markdown, onCite, active }: { markdown: string; onCite: (id: string) => void; active: string | null }) {
  return (
    <>
      {paragraphsOf(markdown).map((block, i) => {
        const lines = block.split("\n");
        if (lines.every((l) => l.startsWith("- "))) {
          return <ul key={i}>{lines.map((l, j) => <li key={j}><Inline text={l.slice(2)} onCite={onCite} active={active} /></li>)}</ul>;
        }
        return <p key={i}><Inline text={block} onCite={onCite} active={active} /></p>;
      })}
    </>
  );
}
