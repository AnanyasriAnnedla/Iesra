"use client";
import { useEffect, useId, useRef, useState } from "react";
import { Copy, Download, Maximize2, X } from "lucide-react";
import { download } from "@/lib/utils";

function cssVar(n: string) { return getComputedStyle(document.documentElement).getPropertyValue(n).trim(); }

export function Mermaid({ source, title }: { source: string; title: string }) {
  const uid = useId().replace(/:/g, "");
  const [svg, setSvg] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [rev, setRev] = useState(0);
  const copied = useRef(false);

  useEffect(() => {
    const mo = new MutationObserver(() => setRev((r) => r + 1));
    mo.observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme"] });
    return () => mo.disconnect();
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const mermaid = (await import("mermaid")).default;
        mermaid.initialize({
          startOnLoad: false, securityLevel: "strict", theme: "base",
          fontFamily: '"Instrument Sans Variable", system-ui, sans-serif',
          themeVariables: {
            background: "transparent", primaryColor: cssVar("--surface"), primaryTextColor: cssVar("--ink"), primaryBorderColor: cssVar("--ink-2"),
            lineColor: cssVar("--ink-2"), secondaryColor: cssVar("--reason-tint"), tertiaryColor: cssVar("--viz-tint"), textColor: cssVar("--ink"),
            cScale0: cssVar("--reason"), cScale1: cssVar("--viz"), cScale2: cssVar("--warn"), cScale3: cssVar("--ok"),
          },
        });
        const { svg } = await mermaid.render(`mm-${uid}-${rev}`, source);
        if (!cancelled) { setSvg(svg); setErr(null); }
      } catch (e) { if (!cancelled) setErr((e as Error).message); }
    })();
    return () => { cancelled = true; };
  }, [source, rev, uid]);

  if (err) return (
    <div className="rounded-md border border-bad bg-bad-tint p-4 text-sm">
      <p className="font-medium text-bad">This diagram could not be drawn.</p>
      <p className="hint mt-1">The source is shown below so you can fix or report it.</p>
      <pre className="mt-3 overflow-x-auto text-xs">{source}</pre>
    </div>
  );
  return (
    <div className="group relative rounded-md border border-line bg-surface p-4">
      <div className="no-print absolute right-2 top-2 flex gap-1">
        <button className="btn-ghost !p-1.5" aria-label="Copy Mermaid source" title="Copy Mermaid source" onClick={() => { navigator.clipboard.writeText(source); copied.current = true; }}><Copy size={15} /></button>
        <button className="btn-ghost !p-1.5" aria-label="Download SVG" title="Download SVG" onClick={() => download(`${title.replace(/\W+/g, "-").toLowerCase()}.svg`, svg, "image/svg+xml")}><Download size={15} /></button>
        <button className="btn-ghost !p-1.5" aria-label="View full screen" title="View full screen" onClick={() => setOpen(true)}><Maximize2 size={15} /></button>
      </div>
      <div className="overflow-x-auto pt-5 [&_svg]:mx-auto [&_svg]:h-auto [&_svg]:max-w-full" role="img" aria-label={title} dangerouslySetInnerHTML={{ __html: svg || "" }} />
      {!svg && <p className="py-10 text-center text-sm text-mute">Drawing diagram…</p>}
      {open && (
        <div role="dialog" aria-modal="true" aria-label={title} className="fixed inset-0 z-50 grid place-items-center bg-[color-mix(in_srgb,var(--ink)_55%,transparent)] p-6" onClick={() => setOpen(false)}>
          <div className="max-h-full w-full max-w-6xl overflow-auto rounded-lg bg-surface p-6" onClick={(e) => e.stopPropagation()}>
            <button className="btn-quiet mb-3" onClick={() => setOpen(false)}><X size={14} /> Close</button>
            <div className="[&_svg]:mx-auto [&_svg]:h-auto [&_svg]:max-w-full" dangerouslySetInnerHTML={{ __html: svg }} />
          </div>
        </div>
      )}
    </div>
  );
}
