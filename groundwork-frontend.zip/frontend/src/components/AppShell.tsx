"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { History, Moon, PlusCircle, Sun } from "lucide-react";
import { USE_MOCK } from "@/lib/api";
import { cn } from "@/lib/utils";

export function Mark({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 28 28" fill="none" aria-hidden>
      <path d="M3 14h6" stroke="var(--ink)" strokeWidth="2.2" strokeLinecap="round" />
      <path d="M9 14c4 0 4-7 8-7h8" stroke="var(--reason)" strokeWidth="2.2" strokeLinecap="round" />
      <path d="M9 14c4 0 4 7 8 7h8" stroke="var(--viz)" strokeWidth="2.2" strokeLinecap="round" />
    </svg>
  );
}

const NAV = [
  { href: "/", label: "New run", icon: PlusCircle, match: (p: string) => p === "/" },
  { href: "/runs", label: "Run history", icon: History, match: (p: string) => p.startsWith("/runs") },
];

export function AppShell({ children }: { children: React.ReactNode }) {
  const path = usePathname();
  const [theme, setTheme] = useState<"light" | "dark">("light");
  useEffect(() => setTheme((document.documentElement.dataset.theme as "light" | "dark") ?? "light"), []);
  const flip = () => {
    const next = theme === "dark" ? "light" : "dark";
    document.documentElement.dataset.theme = next;
    try { localStorage.setItem("gw.theme", next); } catch {}
    setTheme(next);
  };
  return (
    <div className="min-h-screen md:grid md:grid-cols-[232px_1fr]">
      <aside className="no-print sticky top-0 z-30 flex items-center justify-between gap-4 border-b border-line bg-paper px-4 py-3 md:h-screen md:flex-col md:items-stretch md:justify-start md:gap-8 md:border-b-0 md:border-r md:px-5 md:py-6">
        <Link href="/" className="flex items-center gap-2.5">
          <Mark />
          <span className="font-serif text-[22px] font-semibold leading-none tracking-tight">Groundwork</span>
        </Link>
        <nav aria-label="Main" className="flex gap-1 md:flex-col">
          {NAV.map(({ href, label, icon: Icon, match }) => (
            <Link key={href} href={href} aria-current={match(path) ? "page" : undefined}
              className={cn("flex items-center gap-2.5 rounded-md px-3 py-2 text-sm", match(path) ? "bg-surface font-medium text-ink shadow-[inset_0_0_0_1px_var(--line)]" : "text-mute hover:bg-sunken hover:text-ink")}>
              <Icon size={16} aria-hidden /> <span className="hidden sm:inline">{label}</span>
            </Link>
          ))}
        </nav>
        <div className="hidden flex-1 md:block" />
        <div className="flex items-center gap-2 md:flex-col md:items-stretch">
          <p className={cn("rounded-md px-3 py-2 text-xs leading-snug", USE_MOCK ? "bg-warn-tint text-warn" : "bg-ok-tint text-ok")}>
            {USE_MOCK ? "Sample data. No backend connected." : "Connected to the live API."}
          </p>
          <button onClick={flip} className="btn-ghost justify-start px-3 text-sm" aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} theme`}>
            {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />} <span className="hidden md:inline">{theme === "dark" ? "Light theme" : "Dark theme"}</span>
          </button>
        </div>
      </aside>
      <main className="min-w-0 px-5 py-8 md:px-10 md:py-10">{children}</main>
    </div>
  );
}
