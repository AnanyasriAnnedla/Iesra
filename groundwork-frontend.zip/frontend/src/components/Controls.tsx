"use client";
import { useId } from "react";
import { cn } from "@/lib/utils";

export function Slider({ label, hint, value, min, max, step = 1, onChange, suffix }: {
  label: string; hint?: string; value: number; min: number; max: number; step?: number; suffix?: string; onChange: (n: number) => void;
}) {
  const id = useId();
  const fill = ((value - min) / (max - min)) * 100;
  return (
    <div>
      <div className="flex items-baseline justify-between gap-3">
        <label htmlFor={id} className="label">{label}</label>
        <output htmlFor={id} className="tabnum text-sm font-medium">{value}{suffix}</output>
      </div>
      <input id={id} type="range" min={min} max={max} step={step} value={value} style={{ ["--fill" as string]: `${fill}%` }}
        onChange={(e) => onChange(Number(e.target.value))} aria-describedby={hint ? `${id}-h` : undefined} />
      {hint && <p id={`${id}-h`} className="hint -mt-0.5">{hint}</p>}
    </div>
  );
}

export function Toggle({ label, hint, checked, onChange }: { label: string; hint?: string; checked: boolean; onChange: (b: boolean) => void }) {
  const id = useId();
  return (
    <div className="flex items-start justify-between gap-4">
      <div>
        <label htmlFor={id} className="label">{label}</label>
        {hint && <p className="hint">{hint}</p>}
      </div>
      <button id={id} role="switch" aria-checked={checked} onClick={() => onChange(!checked)}
        className={cn("relative mt-0.5 h-6 w-10 shrink-0 rounded-full transition-colors", checked ? "bg-ink" : "bg-line")}>
        <span className={cn("absolute top-0.5 h-5 w-5 rounded-full bg-surface transition-all", checked ? "left-[18px]" : "left-0.5")} />
      </button>
    </div>
  );
}

export function Segmented<T extends string>({ label, value, options, onChange }: {
  label: string; value: T; options: { value: T; label: string }[]; onChange: (v: T) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="label">{label}</span>
      <div role="radiogroup" aria-label={label} className="inline-flex rounded-md border border-line bg-sunken p-0.5">
        {options.map((o) => (
          <button key={o.value} role="radio" aria-checked={value === o.value} onClick={() => onChange(o.value)}
            className={cn("rounded-[6px] px-3 py-1 text-[13px]", value === o.value ? "bg-surface font-medium shadow-[0_0_0_1px_var(--line)]" : "text-mute hover:text-ink")}>
            {o.label}
          </button>
        ))}
      </div>
    </div>
  );
}
