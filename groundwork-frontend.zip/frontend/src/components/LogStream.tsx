"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import type { RunEvent, StageId } from "@/lib/types";
import { STAGE_LABEL, cn, fmtTime } from "@/lib/utils";

export function LogStream({ events, stage, onClearStage }: { events: RunEvent[]; stage: StageId | null; onClearStage: () => void }) {
  const [onlyIssues, setOnlyIssues] = useState(false);
  const [follow, setFollow] = useState(true);
  const box = useRef<HTMLOListElement>(null);
  const rows = useMemo(() => events.filter((e) => (!stage || e.stage === stage) && (!onlyIssues || e.level !== "info")), [events, stage, onlyIssues]);
  useEffect(() => { if (follow && box.current) box.current.scrollTop = box.current.scrollHeight; }, [rows, follow]);
  return (
    <section aria-labelledby="log-h">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
        <h2 id="log-h" className="font-serif text-xl font-semibold">Live log</h2>
        <div className="flex flex-wrap items-center gap-2 text-[13px]">
          {stage && <button onClick={onClearStage} className="rounded-full bg-reason-tint px-3 py-1 text-reason">{STAGE_LABEL[stage]} only. Show all</button>}
          <label className="flex items-center gap-1.5 text-mute"><input type="checkbox" checked={onlyIssues} onChange={(e) => setOnlyIssues(e.target.checked)} /> Warnings and errors</label>
          <label className="flex items-center gap-1.5 text-mute"><input type="checkbox" checked={follow} onChange={(e) => setFollow(e.target.checked)} /> Follow new lines</label>
        </div>
      </div>
      <ol ref={box} role="log" aria-live="polite" className="max-h-[360px] divide-y divide-line overflow-y-auto rounded-md border border-line bg-surface">
        {rows.length === 0 && <li className="px-4 py-6 text-sm text-mute">{events.length === 0 ? "Waiting for the first event." : "No lines match these filters."}</li>}
        {rows.map((e) => (
          <li key={e.id} className="grid grid-cols-[64px_120px_1fr] gap-3 px-4 py-2 text-[13px]">
            <time className="tabnum text-faint">{fmtTime(e.ts)}</time>
            <span className="truncate text-mute">{STAGE_LABEL[e.stage]}</span>
            <span className={cn(e.level === "warn" && "text-warn", e.level === "error" && "font-medium text-bad")}>
              {e.level !== "info" && <span className="sr-only">{e.level}: </span>}{e.message}
            </span>
          </li>
        ))}
      </ol>
    </section>
  );
}
