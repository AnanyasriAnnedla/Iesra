"use client";
import Link from "next/link";
import { useParams, usePathname } from "next/navigation";
import { FileDown, Play, Printer } from "lucide-react";
import { api } from "@/lib/api";
import { RunContext, useRunPolling } from "@/lib/hooks";
import { StatusPill } from "@/components/StatusPill";
import { cn, fmtDate, fmtDuration, hasReport } from "@/lib/utils";
import { useState } from "react";

export default function RunLayout({ children }: { children: React.ReactNode }) {
  const { id } = useParams<{ id: string }>();
  const path = usePathname();
  const { run, error, refresh } = useRunPolling(id);
  const [resuming, setResuming] = useState(false);

  if (error && !run) return (
    <div className="mx-auto max-w-xl rounded-lg border border-line bg-surface p-8 text-center">
      <p className="font-serif text-2xl">This run could not be loaded</p>
      <p className="hint mt-2">{error}. It may have been deleted, or the backend is not running.</p>
      <Link href="/runs" className="btn-quiet mt-5">Back to run history</Link>
    </div>
  );
  if (!run) return <p className="text-sm text-mute" role="status">Loading run…</p>;

  const base = `/runs/${id}`;
  const ready = hasReport(run.status);
  const tabs = [
    { href: base, label: "Progress", on: path === base },
    { href: `${base}/report`, label: "Report", on: path.endsWith("/report"), off: !ready },
    { href: `${base}/evidence`, label: "Evidence", on: path.endsWith("/evidence"), off: run.counts.gaps === 0 },
    { href: `${base}/rate`, label: "Rate", on: path.endsWith("/rate"), off: run.counts.gaps === 0 },
  ];
  async function resume() { setResuming(true); try { await api.resumeRun(id); await refresh(); } finally { setResuming(false); } }

  return (
    <RunContext.Provider value={{ run, refresh }}>
      <div className="mx-auto max-w-[1180px]">
        <header className="no-print">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="min-w-0">
              <h1 className="max-w-[28ch] font-serif text-[34px] font-semibold leading-[1.12] tracking-tight md:text-4xl">{run.topic}</h1>
              <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 text-[13px] text-mute">
                <StatusPill status={run.status} />
                <span className="tabnum">{run.id}</span><span>Started {fmtDate(run.created_at)}</span>
                <span className="tabnum">{fmtDuration(run.usage.seconds)}</span>
              </div>
            </div>
            <div className="flex gap-2">
              {run.status === "paused" && <button className="btn-primary" onClick={resume} disabled={resuming}><Play size={15} /> {resuming ? "Resuming…" : "Resume run"}</button>}
              {ready && path.endsWith("/report") && <button className="btn-quiet" onClick={() => window.print()}><Printer size={15} /> Print or save PDF</button>}
              {ready && !path.endsWith("/report") && <Link className="btn-primary" href={`${base}/report`}><FileDown size={15} /> Open report</Link>}
            </div>
          </div>
          <nav aria-label="Run sections" className="mt-7 flex gap-1 border-b border-line">
            {tabs.map((t) => t.off ? (
              <span key={t.label} className="cursor-not-allowed px-4 py-2.5 text-sm text-faint" aria-disabled title="Available once this stage finishes">{t.label}</span>
            ) : (
              <Link key={t.label} href={t.href} aria-current={t.on ? "page" : undefined}
                className={cn("-mb-px border-b-2 px-4 py-2.5 text-sm", t.on ? "border-ink font-medium" : "border-transparent text-mute hover:text-ink")}>{t.label}</Link>
            ))}
          </nav>
        </header>
        <div className="pt-8">{children}</div>
      </div>
    </RunContext.Provider>
  );
}
