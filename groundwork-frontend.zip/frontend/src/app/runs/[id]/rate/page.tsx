"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import { api } from "@/lib/api";
import { useAsync, useRun } from "@/lib/hooks";
import type { Rating, RatingLabel } from "@/lib/types";
import { cn } from "@/lib/utils";

const LABELS: { value: RatingLabel; key: string; title: string; help: string }[] = [
  { value: "real", key: "1", title: "Real", help: "The papers clearly support this, and it is worth pursuing." },
  { value: "plausible", key: "2", title: "Plausible", help: "Could be true, but the evidence is thin or the wording is loose." },
  { value: "hallucinated", key: "3", title: "Hallucinated", help: "The papers do not support this, or it contradicts them." },
];

export default function RatePage() {
  const { run } = useRun();
  const st = useAsync(() => api.getState(run.id), [run.id]);
  const rated = useAsync(() => api.listRatings(run.id), [run.id]);
  const [rater, setRater] = useState("");
  const [idx, setIdx] = useState(0);
  const [note, setNote] = useState("");
  const [saved, setSaved] = useState<Rating[]>([]);
  useEffect(() => { setRater(localStorage.getItem("gw.rater") ?? ""); }, []);
  useEffect(() => { if (rated.data) setSaved(rated.data); }, [rated.data]);

  const items = useMemo(() => {
    const d = st.data; if (!d) return [];
    return [
      ...d.gaps.map((g) => ({ id: g.gap_id, kind: "gap" as const, text: g.claim, detail: Object.entries(g.stats).map(([k, v]) => `${k.replace(/_/g, " ")}: ${v}`).join(", "), papers: g.supporting_paper_ids })),
      ...d.hypotheses.map((h) => ({ id: h.hyp_id, kind: "hypothesis" as const, text: h.text, detail: h.rationale, papers: h.supporting_paper_ids })),
    ];
  }, [st.data]);
  const mine = saved.filter((r) => r.rater === rater.trim());
  const cur = items[idx];
  const title = (id: string) => st.data?.papers.find((p) => p.paper_id === id)?.title ?? id;

  const rate = useCallback(async (label: RatingLabel) => {
    if (!cur || !rater.trim()) return;
    const r: Rating = { target_id: cur.id, kind: cur.kind, label, rater: rater.trim(), note: note || undefined };
    localStorage.setItem("gw.rater", rater.trim());
    await api.postRating(run.id, r);
    setSaved((s) => [...s.filter((x) => !(x.target_id === r.target_id && x.rater === r.rater)), r]);
    setNote(""); setIdx((i) => Math.min(i + 1, items.length - 1));
  }, [cur, rater, note, run.id, items.length]);

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement).matches("input,textarea")) return;
      const l = LABELS.find((x) => x.key === e.key); if (l) rate(l.value);
    };
    window.addEventListener("keydown", h); return () => window.removeEventListener("keydown", h);
  }, [rate]);

  if (!st.data) return <p className="text-sm text-mute" role="status">Loading items…</p>;
  const done = items.filter((i) => mine.some((r) => r.target_id === i.id)).length;
  const existing = cur && mine.find((r) => r.target_id === cur.id);

  return (
    <div className="mx-auto max-w-[720px]">
      <h2 className="font-serif text-3xl font-semibold">Rate gaps and hypotheses</h2>
      <p className="mt-2 text-mute">Judge each claim only from the papers shown. These ratings feed the grounding and Critic experiments.</p>
      <div className="mt-6 flex flex-wrap items-end gap-4">
        <div className="min-w-[200px] flex-1"><label htmlFor="rater" className="label">Your name or rater ID</label>
          <input id="rater" className="input mt-1" value={rater} onChange={(e) => setRater(e.target.value)} placeholder="For example: rater-1" /></div>
        <p className="tabnum pb-2 text-sm text-mute">{done} of {items.length} rated</p>
      </div>
      <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-line"><div className="h-full bg-ink transition-all" style={{ width: `${items.length ? (done / items.length) * 100 : 0}%` }} /></div>

      {!cur ? <p className="mt-10 text-sm text-mute">There is nothing to rate yet.</p> : (
        <section className="mt-8 rounded-lg border border-line bg-surface p-6" aria-live="polite">
          <p className="text-xs font-medium text-mute">{cur.kind === "gap" ? "Gap" : "Hypothesis"} {idx + 1} of {items.length}</p>
          <p className="mt-2 font-serif text-2xl leading-snug">{cur.text}</p>
          <p className="hint mt-3">{cur.detail}</p>
          <details className="mt-4 text-sm"><summary className="cursor-pointer text-mute">Papers behind this ({cur.papers.length})</summary>
            <ul className="mt-2 space-y-1">{cur.papers.map((p) => <li key={p}><span className="cite">{p}</span> {title(p)}</li>)}</ul></details>
          <div role="group" aria-label="Your rating" className="mt-6 grid gap-2 sm:grid-cols-3">
            {LABELS.map((l) => (
              <button key={l.value} disabled={!rater.trim()} onClick={() => rate(l.value)} aria-pressed={existing?.label === l.value}
                className={cn("rounded-md border p-3 text-left disabled:opacity-50", existing?.label === l.value ? "border-ink bg-sunken" : "border-line hover:bg-sunken")}>
                <span className="flex items-center justify-between font-medium">{l.title}<kbd className="rounded border border-line px-1.5 text-xs text-mute">{l.key}</kbd></span>
                <span className="hint mt-1 block">{l.help}</span>
              </button>
            ))}
          </div>
          {!rater.trim() && <p className="hint mt-3">Enter a rater ID first so ratings can be compared across raters.</p>}
          <label htmlFor="note" className="label mt-5 block">Note (optional)</label>
          <textarea id="note" rows={2} className="input mt-1 resize-none" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Why did you choose this rating?" />
          <div className="mt-5 flex justify-between">
            <button className="btn-quiet" disabled={idx === 0} onClick={() => setIdx(idx - 1)}>Previous</button>
            <button className="btn-quiet" disabled={idx >= items.length - 1} onClick={() => setIdx(idx + 1)}>Skip</button>
          </div>
        </section>
      )}
    </div>
  );
}
