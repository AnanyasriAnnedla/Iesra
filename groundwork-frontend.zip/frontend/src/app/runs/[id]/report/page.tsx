"use client";
import Link from "next/link";
import { useMemo, useState } from "react";
import { AlertTriangle, Download } from "lucide-react";
import { api } from "@/lib/api";
import { useAsync, useRun } from "@/lib/hooks";
import { Mermaid } from "@/components/Mermaid";
import { Prose } from "@/components/Prose";
import { SourcePanel } from "@/components/SourcePanel";
import { download, hasReport } from "@/lib/utils";

export default function ReportPage() {
  const { run } = useRun();
  const ready = hasReport(run.status);
  const rep = useAsync(() => (ready ? api.getReport(run.id) : Promise.resolve(null)), [run.id, ready]);
  const dia = useAsync(() => (ready ? api.getDiagrams(run.id) : Promise.resolve([])), [run.id, ready]);
  const st = useAsync(() => (ready ? api.getState(run.id) : Promise.resolve(null)), [run.id, ready]);
  const [active, setActive] = useState<string | null>(null);

  const papers = useMemo(() => new Map((st.data?.papers ?? []).map((p) => [p.paper_id, p])), [st.data]);
  const extr = useMemo(() => new Map((st.data?.extractions ?? []).map((e) => [e.paper_id, e])), [st.data]);

  if (!ready) return (
    <div className="mx-auto max-w-lg rounded-lg border border-dashed border-line p-10 text-center">
      <p className="font-serif text-2xl">The report is written last</p>
      <p className="hint mt-2">It starts once both the reasoning and visualization branches finish.</p>
      <Link href={`/runs/${run.id}`} className="btn-quiet mt-5">See progress</Link>
    </div>
  );
  if (rep.error) return <p role="alert" className="rounded-md bg-bad-tint p-4 text-sm text-bad">Could not load the report: {rep.error}</p>;
  if (!rep.data) return <p className="text-sm text-mute" role="status">Loading report…</p>;
  const report = rep.data;
  const diagrams = dia.data ?? [];
  const skipped = diagrams.filter((d) => d.status !== "ok");
  const refs = [...new Set(report.sections.flatMap((s) => s.cited_paper_ids))].sort();
  const paper = active ? papers.get(active) : undefined;

  const exportMd = () => download(`${run.topic.replace(/\W+/g, "-").toLowerCase()}.md`, `# ${run.topic}\n\n` + report.sections.map((s) => `## ${s.title}\n\n${s.markdown.replace(/\[@(\w+)\]/g, "[$1]").replace(/\[\?\]/g, "[citation needed]")}`).join("\n\n"), "text/markdown");

  return (
    <div className="grid gap-10 lg:grid-cols-[170px_minmax(0,1fr)] xl:grid-cols-[170px_minmax(0,1fr)_320px]">
      <nav aria-label="Report sections" className="no-print hidden lg:block">
        <ol className="sticky top-8 space-y-1 border-l border-line text-[13px]">
          {report.sections.map((s) => <li key={s.slot}><a href={`#${s.slot}`} className="-ml-px block border-l-2 border-transparent py-1 pl-3 text-mute hover:border-ink hover:text-ink">{s.title}</a></li>)}
          <li><a href="#references" className="-ml-px block border-l-2 border-transparent py-1 pl-3 text-mute hover:border-ink hover:text-ink">References</a></li>
        </ol>
        <button onClick={exportMd} className="btn-ghost sticky top-[22rem] mt-6 !px-0 text-[13px]"><Download size={14} /> Download Markdown</button>
      </nav>

      <article className="report min-w-0">
        {(report.uncited_sentence_count > 0 || skipped.length > 0 || report.unresolved_items.length > 0) && (
          <aside className="not-prose mb-10 rounded-md border border-warn bg-warn-tint p-4 font-sans text-[14px] leading-snug text-ink">
            <p className="flex items-center gap-2 font-medium text-warn"><AlertTriangle size={16} /> Quality summary</p>
            <ul className="mt-2 list-disc space-y-1 pl-5 !max-w-none">
              {report.uncited_sentence_count > 0 && <li>{report.uncited_sentence_count} sentence has no paper citation. It is marked “needs citation” below.</li>}
              {skipped.map((d) => <li key={d.diagram_id}>{d.title} was skipped. {d.skip_reason}</li>)}
              {report.unresolved_items.map((u) => <li key={u}>Unresolved: {u}</li>)}
            </ul>
          </aside>
        )}
        <h1 className="mb-10 font-serif text-[40px] font-semibold leading-[1.1] tracking-tight md:text-5xl">{run.topic}</h1>
        {report.sections.map((s) => (
          <section key={s.slot} id={s.slot} className="mb-12 scroll-mt-8">
            <h2 className="mb-4 font-serif text-[28px] font-semibold leading-tight">{s.title}</h2>
            <Prose markdown={s.markdown} onCite={(id) => setActive(active === id ? null : id)} active={active} />
            {diagrams.filter((d) => d.report_slot === s.slot && d.status === "ok").map((d) => (
              <figure key={d.diagram_id} className="my-6 max-w-[760px]">
                <Mermaid source={d.mermaid_source} title={d.title} />
                <figcaption className="mt-2 font-sans text-[13px] leading-snug text-mute">
                  {d.title}. {d.generation === "deterministic" ? "Built by code from the graph." : "Drawn by the LLM from graph items."} Sources:{" "}
                  {d.source_paper_ids.map((p) => <button key={p} className="cite" onClick={() => setActive(p)}>{p}</button>)}
                </figcaption>
              </figure>
            ))}
          </section>
        ))}
        <section id="references" className="scroll-mt-8">
          <h2 className="mb-4 font-serif text-[28px] font-semibold">References</h2>
          <ol className="max-w-[66ch] space-y-2 font-sans text-[14px] leading-snug">
            {refs.map((id) => { const p = papers.get(id); return (
              <li key={id} className="flex gap-3"><button className="cite self-start" onClick={() => setActive(id)}>{id}</button><span>{p ? `${p.title}. ${[p.venue, p.year].filter(Boolean).join(", ")}.` : "Paper details unavailable."}</span></li>
            ); })}
          </ol>
        </section>
      </article>

      <aside aria-label="Selected source" className="no-print hidden xl:block">
        <div className="sticky top-8">
          {paper ? <SourcePanel paper={paper} extraction={extr.get(paper.paper_id)} onClose={() => setActive(null)} /> : (
            <div className="rounded-md border border-dashed border-line p-5 text-sm text-mute"><p className="font-medium text-ink">Check any claim</p><p className="mt-1">Select a citation such as <span className="cite">P05</span> to see the paper, the facts taken from it, and the quoted snippet that proves each one.</p></div>
          )}
        </div>
      </aside>

      {paper && (
        <div className="no-print fixed inset-x-0 bottom-0 z-40 max-h-[60vh] overflow-y-auto border-t border-line bg-paper p-4 xl:hidden">
          <SourcePanel paper={paper} extraction={extr.get(paper.paper_id)} onClose={() => setActive(null)} />
        </div>
      )}
    </div>
  );
}
