"use client";
import { useEffect, useMemo, useState } from "react";
import { api } from "@/lib/api";
import { useAsync, useRun } from "@/lib/hooks";
import { GraphNeighborhood } from "@/components/GraphNeighborhood";
import { SourcePanel } from "@/components/SourcePanel";
import type { CriticCheck, Gap, Hypothesis, ItemStatus } from "@/lib/types";
import { GAP_TYPE_LABEL, cn } from "@/lib/utils";
import { Check, X } from "lucide-react";

const STATUS_STYLE: Record<ItemStatus, string> = { accepted: "bg-ok-tint text-ok", rejected: "bg-bad-tint text-bad", unresolved: "bg-warn-tint text-warn", candidate: "bg-sunken text-mute" };
const CHECK_LABEL: Record<CriticCheck, string> = {
  is_real_gap: "Really a gap", enough_support: "Enough supporting papers", evidence_chain_sound: "Evidence chain is sound",
  not_already_published: "Not already published", entities_not_aliases: "Items are not aliases of each other",
};
const Badge = ({ s }: { s: ItemStatus }) => <span className={cn("rounded-full px-2 py-0.5 text-xs font-medium", STATUS_STYLE[s])}>{s}</span>;

export default function EvidencePage() {
  const { run } = useRun();
  const st = useAsync(() => api.getState(run.id), [run.id]);
  const [sel, setSel] = useState<string | null>(null);
  const [paperId, setPaperId] = useState<string | null>(null);
  const gaps = useMemo(() => st.data?.gaps ?? [], [st.data]);
  useEffect(() => { if (!sel && gaps.length) setSel(gaps[0].gap_id); }, [gaps, sel]);
  const ev = useAsync(() => (sel ? api.getEvidence(run.id, sel) : Promise.resolve(null)), [run.id, sel]);

  const gap: Gap | undefined = useMemo(() => gaps.find((g) => g.gap_id === sel), [gaps, sel]);
  const hyps: Hypothesis[] = useMemo(() => (st.data?.hypotheses ?? []).filter((h) => h.gap_id === sel), [st.data, sel]);
  const verdicts = (st.data?.critic_verdicts ?? []).filter((v) => v.target_id === sel || hyps.some((h) => h.hyp_id === v.target_id)).sort((a, b) => a.round - b.round);
  const papers = new Map((st.data?.papers ?? []).map((p) => [p.paper_id, p]));
  const extr = new Map((st.data?.extractions ?? []).map((e) => [e.paper_id, e]));

  if (st.error) return <p role="alert" className="rounded-md bg-bad-tint p-4 text-sm text-bad">Could not load evidence: {st.error}</p>;
  if (!st.data) return <p className="text-sm text-mute" role="status">Loading evidence…</p>;
  if (gaps.length === 0) return <div className="rounded-lg border border-dashed border-line p-10 text-center"><p className="font-serif text-xl">No evidence-backed gaps were found</p><p className="hint mt-1">Groundwork never invents a gap. Try a broader topic or lower the “well studied” threshold.</p></div>;
  const open = paperId ? papers.get(paperId) : undefined;

  return (
    <div className="grid gap-8 lg:grid-cols-[320px_1fr]">
      <nav aria-label="Gaps">
        <h2 className="mb-3 font-serif text-xl font-semibold">Gaps</h2>
        <ul className="space-y-2">
          {gaps.map((g) => (
            <li key={g.gap_id}><button onClick={() => { setSel(g.gap_id); setPaperId(null); }} aria-current={sel === g.gap_id}
              className={cn("w-full rounded-md border p-3 text-left", sel === g.gap_id ? "border-ink bg-surface" : "border-line hover:bg-sunken")}>
              <div className="flex items-center justify-between gap-2"><span className="text-xs font-medium text-mute">{GAP_TYPE_LABEL[g.gap_type].name}</span><Badge s={g.status} /></div>
              <p className="mt-1.5 line-clamp-3 text-sm">{g.claim}</p>
            </button></li>
          ))}
        </ul>
      </nav>

      {gap && (
        <div className="min-w-0 space-y-8">
          <section>
            <p className="text-sm text-mute">{GAP_TYPE_LABEL[gap.gap_type].plain}</p>
            <h2 className="mt-1 max-w-[52ch] font-serif text-2xl font-semibold leading-snug">{gap.claim}</h2>
            <dl className="mt-4 flex flex-wrap gap-x-8 gap-y-3">
              {Object.entries(gap.stats).map(([k, v]) => <div key={k}><dt className="text-xs text-mute">{k.replace(/_/g, " ")}</dt><dd className="tabnum font-serif text-3xl font-semibold">{v}</dd></div>)}
              <div><dt className="text-xs text-mute">confidence</dt><dd className="font-serif text-3xl font-semibold capitalize">{gap.confidence}</dd></div>
            </dl>
            <p className="hint mt-2">Counts come straight from the graph query. Confidence is calculated by code from these counts, and is capped at medium for abstract-only evidence.</p>
          </section>

          <section aria-labelledby="gr-h">
            <h3 id="gr-h" className="mb-2 font-serif text-xl font-semibold">Graph neighbourhood</h3>
            <div className="rounded-lg border border-line bg-surface p-3">
              {ev.data ? <GraphNeighborhood evidence={ev.data} onPaper={setPaperId} /> : <p className="p-8 text-center text-sm text-mute">Loading graph…</p>}
            </div>
            <p className="hint mt-2">Select a paper node to read what was extracted from it.</p>
          </section>

          <section>
            <h3 className="mb-2 font-serif text-xl font-semibold">Supporting papers</h3>
            <ul className="divide-y divide-line rounded-md border border-line bg-surface">
              {gap.supporting_paper_ids.map((id) => { const p = papers.get(id); return (
                <li key={id}><button onClick={() => setPaperId(id)} className="flex w-full items-baseline gap-3 px-4 py-2.5 text-left text-sm hover:bg-sunken">
                  <span className="cite !cursor-pointer">{id}</span><span className="flex-1">{p?.title}</span><span className="tabnum text-faint">{p?.year}</span></button></li>
              ); })}
            </ul>
          </section>
          {open && <SourcePanel paper={open} extraction={extr.get(open.paper_id)} onClose={() => setPaperId(null)} />}

          <section>
            <h3 className="mb-2 font-serif text-xl font-semibold">Hypotheses for this gap</h3>
            {hyps.length === 0 ? <p className="text-sm text-mute">No hypotheses were kept for this gap.</p> : (
              <ul className="space-y-3">
                {hyps.map((h) => (
                  <li key={h.hyp_id} className="rounded-md border border-line bg-surface p-4">
                    <div className="flex items-start justify-between gap-3"><p className="font-medium">{h.text}</p><Badge s={h.status} /></div>
                    <p className="hint mt-1.5">{h.rationale}</p>
                    <p className="mt-3 text-[13px]"><span className="text-mute">Supports: </span>{h.supporting_paper_ids.map((p) => <button key={p} className="cite" onClick={() => setPaperId(p)}>{p}</button>)}
                      {h.contradicting_paper_ids.length > 0 && <><span className="ml-3 text-mute">Contradicts: </span>{h.contradicting_paper_ids.map((p) => <button key={p} className="cite !bg-bad-tint !text-bad" onClick={() => setPaperId(p)}>{p}</button>)}</>}</p>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section>
            <h3 className="mb-2 font-serif text-xl font-semibold">What the Critic said</h3>
            {verdicts.length === 0 ? <p className="text-sm text-mute">{run.config.critic_enabled ? "No verdicts recorded yet." : "The Critic was off for this run."}</p> : (
              <ul className="space-y-3">
                {verdicts.map((v, i) => (
                  <li key={i} className="rounded-md border border-line bg-surface p-4">
                    <p className="text-sm"><span className="font-medium">{v.target_id}</span> <span className="text-mute">in round {v.round}:</span> <span className={v.verdict === "accept" ? "font-medium text-ok" : "font-medium text-bad"}>{v.verdict === "accept" ? "accepted" : "rejected"}</span></p>
                    <ul className="mt-2 grid gap-x-6 gap-y-1 sm:grid-cols-2">
                      {(Object.keys(CHECK_LABEL) as CriticCheck[]).map((k) => (
                        <li key={k} className="flex items-center gap-2 text-[13px]">{v.checks[k] ? <Check size={14} className="text-ok" aria-label="Passed" /> : <X size={14} className="text-bad" aria-label="Failed" />}{CHECK_LABEL[k]}</li>
                      ))}
                    </ul>
                    {v.reasons.length > 0 && <p className="mt-2 text-sm">{v.reasons.join(" ")}</p>}
                    {v.required_changes.length > 0 && <p className="hint mt-1">Required: {v.required_changes.join(" ")}</p>}
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>
      )}
    </div>
  );
}
