"use client";
import Link from "next/link";
import { useState } from "react";
import { AlertTriangle, ArrowRight, PauseCircle, XCircle } from "lucide-react";
import { useRun, useRunEvents } from "@/lib/hooks";
import type { StageId } from "@/lib/types";
import { PipelineRail } from "@/components/PipelineRail";
import { LogStream } from "@/components/LogStream";
import { fmtNum, hasReport } from "@/lib/utils";

export default function ProgressPage() {
  const { run } = useRun();
  const events = useRunEvents(run.id);
  const [stage, setStage] = useState<StageId | null>(null);
  const warnings = events.filter((e) => e.level !== "info");
  const c = run.counts, u = run.usage;
  const pct = Math.min(100, (u.llm_calls / u.budget) * 100);
  return (
    <div className="space-y-8">
      {run.status === "paused" && (
        <div role="status" className="flex gap-3 rounded-lg border border-warn bg-warn-tint p-4 text-warn"><PauseCircle className="mt-0.5 shrink-0" size={20} />
          <div><p className="font-medium">Run paused</p><p className="text-sm">{run.pause_reason}. Everything so far is saved. Choose “Resume run” above to continue from the last finished step.</p></div></div>
      )}
      {run.status === "failed" && (
        <div role="alert" className="flex gap-3 rounded-lg border border-bad bg-bad-tint p-4 text-bad"><XCircle className="mt-0.5 shrink-0" size={20} />
          <div><p className="font-medium">Run stopped</p><p className="text-sm">{run.fail_reason}</p><Link href="/" className="mt-2 inline-block text-sm underline">Start a new run with a broader topic</Link></div></div>
      )}
      {hasReport(run.status) && (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-line bg-surface p-4">
          <p className="text-sm">{run.status === "completed" ? "The report is ready." : <span className="flex items-center gap-2"><AlertTriangle size={16} className="text-warn" /> The report is ready, with {warnings.length} warnings to review.</span>}</p>
          <Link href={`/runs/${run.id}/report`} className="btn-primary">Read the report <ArrowRight size={15} /></Link>
        </div>
      )}

      <section aria-labelledby="rail-h" className="overflow-x-auto rounded-lg border border-line bg-surface p-5">
        <div className="mb-2 flex items-baseline justify-between gap-4"><h2 id="rail-h" className="font-serif text-xl font-semibold">Pipeline</h2><p className="hint">Select a stage to filter the log.</p></div>
        <PipelineRail run={run} selected={stage} onSelect={setStage} />
      </section>

      <div className="grid gap-8 lg:grid-cols-[1fr_300px]">
        <LogStream events={events} stage={stage} onClearStage={() => setStage(null)} />
        <section aria-labelledby="facts-h">
          <h2 id="facts-h" className="mb-3 font-serif text-xl font-semibold">So far</h2>
          <dl className="divide-y divide-line rounded-md border border-line bg-surface text-sm">
            {([["Papers found", c.papers], ["Usable fact sheets", c.usable], ["Graph nodes", c.nodes], ["Graph edges", c.edges], ["Names merged", c.merges], ["Gaps", c.gaps], ["Hypotheses", c.hypotheses], ["Diagrams", c.diagrams]] as const).map(([k, v]) => (
              <div key={k} className="flex justify-between px-4 py-2.5"><dt className="text-mute">{k}</dt><dd className="tabnum font-medium">{v || "–"}</dd></div>
            ))}
          </dl>
          <div className="mt-5">
            <div className="flex justify-between text-sm"><span className="label">LLM calls</span><span className="tabnum">{u.llm_calls} of {u.budget}</span></div>
            <div className="mt-2 h-2 overflow-hidden rounded-full bg-line" role="progressbar" aria-valuenow={u.llm_calls} aria-valuemin={0} aria-valuemax={u.budget} aria-label="LLM call budget used">
              <div className={pct > 85 ? "h-full bg-warn" : "h-full bg-ink"} style={{ width: `${pct}%` }} />
            </div>
            <p className="hint mt-1.5 tabnum">{fmtNum(u.tokens)} tokens</p>
          </div>
        </section>
      </div>
    </div>
  );
}
