"use client";
import { useMemo, useState } from "react";
import Link from "next/link";
import { Search } from "lucide-react";
import { api } from "@/lib/api";
import { useAsync } from "@/lib/hooks";
import type { RunStatus } from "@/lib/types";
import { StatusPill } from "@/components/StatusPill";
import { STATUS_LABEL, fmtDate, fmtDuration, fmtNum } from "@/lib/utils";

export default function HistoryPage() {
  const { data, error, loading, reload } = useAsync(() => api.listRuns(), []);
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<RunStatus | "all">("all");
  const rows = useMemo(() => (data ?? []).filter((r) => (status === "all" || r.status === status) && r.topic.toLowerCase().includes(q.toLowerCase())), [data, q, status]);
  return (
    <div className="mx-auto max-w-[1100px]">
      <h1 className="font-serif text-4xl font-semibold tracking-tight">Run history</h1>
      <p className="mt-2 text-mute">Every run is saved, so you can reopen a report or resume a paused run.</p>
      <div className="mt-6 flex flex-wrap gap-3">
        <div className="relative min-w-[240px] flex-1">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-faint" aria-hidden />
          <input className="input !pl-9" placeholder="Search topics" aria-label="Search topics" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <select className="input !w-auto" aria-label="Filter by status" value={status} onChange={(e) => setStatus(e.target.value as RunStatus | "all")}>
          <option value="all">All statuses</option>
          {(Object.keys(STATUS_LABEL) as RunStatus[]).map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}
        </select>
        <button className="btn-quiet" onClick={reload}>Refresh</button>
      </div>
      {error && <p role="alert" className="mt-6 rounded-md bg-bad-tint p-4 text-sm text-bad">Could not load runs: {error}. Check that the backend is running.</p>}
      {loading && !data && <p className="mt-8 text-sm text-mute">Loading runs…</p>}
      {data && rows.length === 0 && (
        <div className="mt-10 rounded-lg border border-dashed border-line p-10 text-center">
          <p className="font-serif text-xl">{data.length === 0 ? "No runs yet" : "No runs match"}</p>
          <p className="hint mt-1">{data.length === 0 ? "Start your first run from a research topic." : "Try a different search or status."}</p>
          {data.length === 0 && <Link href="/" className="btn-primary mt-4">New run</Link>}
        </div>
      )}
      {rows.length > 0 && (
        <div className="mt-6 overflow-x-auto rounded-lg border border-line bg-surface">
          <table className="w-full min-w-[760px] text-left text-sm">
            <thead className="border-b border-line text-[13px] text-mute"><tr>
              <th className="px-4 py-3 font-medium">Topic</th><th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 text-right font-medium">Papers</th><th className="px-4 py-3 text-right font-medium">Gaps</th>
              <th className="px-4 py-3 text-right font-medium">LLM calls</th><th className="px-4 py-3 text-right font-medium">Time</th><th className="px-4 py-3 font-medium">Started</th>
            </tr></thead>
            <tbody className="divide-y divide-line">
              {rows.map((r) => (
                <tr key={r.id} className="hover:bg-sunken">
                  <td className="max-w-[340px] px-4 py-3"><Link href={`/runs/${r.id}`} className="font-medium underline-offset-2 hover:underline">{r.topic}</Link></td>
                  <td className="px-4 py-3"><StatusPill status={r.status} /></td>
                  <td className="tabnum px-4 py-3 text-right">{r.counts.usable || r.counts.papers}</td>
                  <td className="tabnum px-4 py-3 text-right">{r.counts.gaps}</td>
                  <td className="tabnum px-4 py-3 text-right">{r.usage.llm_calls} <span className="text-faint">· {fmtNum(r.usage.tokens)} tok</span></td>
                  <td className="tabnum px-4 py-3 text-right">{fmtDuration(r.usage.seconds)}</td>
                  <td className="px-4 py-3 text-mute">{fmtDate(r.created_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
