"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowRight, RotateCcw } from "lucide-react";
import { DEFAULT_CONFIG, api } from "@/lib/api";
import type { DiagramToggle, RunConfig, RunSummary } from "@/lib/types";
import { Segmented, Slider, Toggle } from "@/components/Controls";
import { StatusPill } from "@/components/StatusPill";
import { fmtDate } from "@/lib/utils";

const EXAMPLES = [
  "Explainable conversational recommender systems",
  "Retrieval-augmented generation for clinical question answering",
  "Few-shot learning for low-resource speech recognition",
];
const TOGGLE: { value: DiagramToggle; label: string }[] = [{ value: "auto", label: "Auto" }, { value: "on", label: "Always" }, { value: "off", label: "Never" }];

function Group({ title, note, children }: { title: string; note: string; children: React.ReactNode }) {
  return (
    <fieldset className="grid gap-5 border-t border-line py-7 md:grid-cols-[220px_1fr] md:gap-10">
      <legend className="sr-only">{title}</legend>
      <div aria-hidden><h3 className="font-serif text-lg font-semibold">{title}</h3><p className="hint mt-1">{note}</p></div>
      <div className="space-y-6">{children}</div>
    </fieldset>
  );
}

export default function NewRunPage() {
  const router = useRouter();
  const [topic, setTopic] = useState("");
  const [cfg, setCfg] = useState<RunConfig>(DEFAULT_CONFIG);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [recent, setRecent] = useState<RunSummary[]>([]);
  const area = useRef<HTMLTextAreaElement>(null);
  const set = <K extends keyof RunConfig>(k: K, v: RunConfig[K]) => setCfg((c) => ({ ...c, [k]: v }));

  useEffect(() => { api.listRuns().then((r) => setRecent(r.slice(0, 4))).catch(() => {}); }, []);
  const estCalls = useMemo(() => cfg.max_search_rounds * 2 + 1 + Math.ceil(cfg.max_papers / 2) + cfg.fulltext_top_k * 2 + (cfg.critic_enabled ? cfg.max_critic_rounds * 8 : 0) + 14, [cfg]);
  const valid = topic.trim().length >= 8;
  const changed = JSON.stringify(cfg) !== JSON.stringify(DEFAULT_CONFIG);

  async function start() {
    if (!valid || busy) { area.current?.focus(); return; }
    setBusy(true); setError(null);
    try { const { id } = await api.createRun(topic.trim(), cfg); router.push(`/runs/${id}`); }
    catch (e) { setError((e as Error).message); setBusy(false); }
  }

  return (
    <div className="mx-auto grid max-w-[1180px] gap-12 xl:grid-cols-[1fr_300px]">
      <div>
        <h1 className="font-serif text-[40px] font-semibold leading-[1.1] tracking-tight md:text-5xl">What do you want to find out?</h1>
        <p className="mt-3 max-w-[56ch] text-mute">Enter a research topic. Groundwork finds papers, builds a graph of what they say, and reports only the gaps it can trace back to them.</p>

        <div className="mt-8">
          <label htmlFor="topic" className="label">Research topic</label>
          <textarea id="topic" ref={area} rows={3} value={topic} onChange={(e) => setTopic(e.target.value)}
            onKeyDown={(e) => (e.metaKey || e.ctrlKey) && e.key === "Enter" && start()}
            placeholder="For example: explainable conversational recommender systems"
            className="input mt-1.5 resize-none !rounded-lg !px-4 !py-3 font-serif !text-[22px] leading-snug" aria-describedby="topic-h" />
          <p id="topic-h" className="hint mt-1.5">A noun phrase works best. Press Ctrl or ⌘ + Enter to start.</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {EXAMPLES.map((e) => <button key={e} onClick={() => { setTopic(e); area.current?.focus(); }} className="rounded-full border border-line bg-surface px-3 py-1 text-[13px] text-mute hover:text-ink">{e}</button>)}
          </div>
          <p className="hint mt-2">Test the unhappy paths: a topic containing “fail” stops for lack of papers, and one containing “pause” hits the call budget. Sample mode only.</p>
        </div>

        <div className="mt-10 flex items-center justify-between">
          <h2 className="font-serif text-2xl font-semibold">Run settings</h2>
          <button className="btn-ghost text-[13px]" disabled={!changed} onClick={() => setCfg(DEFAULT_CONFIG)}><RotateCcw size={14} /> Reset to defaults</button>
        </div>
        <div className="mt-3">
          <Group title="Finding papers" note="How wide to search before reading.">
            <Slider label="Papers to keep" value={cfg.max_papers} min={10} max={60} onChange={(v) => set("max_papers", v)} hint="Search stops here, or earlier if a round adds fewer than 3 new papers." />
            <Slider label="Search rounds" value={cfg.max_search_rounds} min={1} max={6} onChange={(v) => set("max_search_rounds", v)} hint="After each round the LLM proposes sharper queries from new terms." />
            <Slider label="Minimum usable papers" value={cfg.min_usable_papers} min={5} max={20} onChange={(v) => set("min_usable_papers", v)} hint="Below this the run stops with a “not enough evidence” message." />
          </Group>
          <Group title="Reading" note="Abstracts for every paper, full text for a few.">
            <Slider label="Papers read at once" value={cfg.extraction_concurrency} min={1} max={16} onChange={(v) => set("extraction_concurrency", v)} hint="Higher is faster but hits API rate limits sooner." />
            <Slider label="Papers read in full text" value={cfg.fulltext_top_k} min={0} max={15} onChange={(v) => set("fulltext_top_k", v)} hint="Only used for architecture and sequence diagrams. 0 skips both." />
          </Group>
          <Group title="Gaps and checking" note="What counts as a gap, and how hard the Critic pushes back.">
            <Slider label="“Well studied” means at least" suffix=" papers" value={cfg.min_papers_well_studied} min={2} max={12} onChange={(v) => set("min_papers_well_studied", v)} />
            <Slider label="Dataset is popular when used by" suffix=" methods" value={cfg.min_methods_per_dataset} min={2} max={8} onChange={(v) => set("min_methods_per_dataset", v)} />
            <Slider label="A method needs at least" suffix=" datasets" value={cfg.min_datasets_per_method} min={1} max={5} onChange={(v) => set("min_datasets_per_method", v)} />
            <Slider label="“Rare” means at most" suffix=" joint papers" value={cfg.max_joint_papers} min={0} max={5} onChange={(v) => set("max_joint_papers", v)} />
            <Slider label="Critic rounds" value={cfg.max_critic_rounds} min={1} max={5} onChange={(v) => set("max_critic_rounds", v)} hint="Anything still rejected afterwards is kept and marked unresolved." />
            <Toggle label="Run the Critic" checked={cfg.critic_enabled} onChange={(b) => set("critic_enabled", b)} hint="Turn off to compare results with and without it for your evaluation." />
            <Toggle label="Merge duplicate names" checked={cfg.name_merging_enabled} onChange={(b) => set("name_merging_enabled", b)} hint="Turn off to measure how many false gaps merging prevents." />
          </Group>
          <Group title="Diagrams" note="The concept map is always drawn. Others follow the topic when set to Auto.">
            {(["timeline", "comparison", "architecture", "sequence"] as const).map((k) => (
              <Segmented key={k} label={{ timeline: "Timeline", comparison: "Method comparison", architecture: "Architecture", sequence: "Sequence" }[k]} value={cfg.diagram_plan[k]} options={TOGGLE}
                onChange={(v) => set("diagram_plan", { ...cfg.diagram_plan, [k]: v })} />
            ))}
            <Slider label="Concept map size" suffix=" items" value={cfg.graph_node_cap_concept_map} min={10} max={50} onChange={(v) => set("graph_node_cap_concept_map", v)} hint="The most connected graph items are shown." />
          </Group>
          <Group title="Budget" note="A hard stop on spending.">
            <Slider label="LLM-call budget" value={cfg.llm_call_budget} min={50} max={1000} step={10} onChange={(v) => set("llm_call_budget", v)} hint="The run pauses when this is reached. You can raise it and resume." />
          </Group>
        </div>
      </div>

      <aside className="xl:sticky xl:top-10 xl:self-start">
        <div className="rounded-lg border border-line bg-surface p-5">
          <h2 className="font-serif text-lg font-semibold">This run</h2>
          <dl className="mt-3 space-y-2 text-sm">
            <div className="flex justify-between"><dt className="text-mute">Papers</dt><dd className="tabnum">up to {cfg.max_papers}</dd></div>
            <div className="flex justify-between"><dt className="text-mute">Critic</dt><dd>{cfg.critic_enabled ? `up to ${cfg.max_critic_rounds} rounds` : "off"}</dd></div>
            <div className="flex justify-between"><dt className="text-mute">Name merging</dt><dd>{cfg.name_merging_enabled ? "on" : "off"}</dd></div>
            <div className="flex justify-between"><dt className="text-mute">Est. LLM calls</dt><dd className={`tabnum ${estCalls > cfg.llm_call_budget ? "font-medium text-bad" : ""}`}>~{estCalls} of {cfg.llm_call_budget}</dd></div>
          </dl>
          {estCalls > cfg.llm_call_budget && <p className="mt-3 rounded bg-bad-tint px-3 py-2 text-[13px] text-bad">This is likely to hit the budget and pause. Raise the budget or reduce papers.</p>}
          {(!cfg.critic_enabled || !cfg.name_merging_enabled) && <p className="mt-3 rounded bg-warn-tint px-3 py-2 text-[13px] text-warn">An ablation switch is off. Label this run in your notes.</p>}
          {error && <p role="alert" className="mt-3 rounded bg-bad-tint px-3 py-2 text-[13px] text-bad">Could not start the run: {error}. Check that the backend is running at the API URL.</p>}
          <button className="btn-primary mt-4 w-full" onClick={start} disabled={busy} aria-disabled={!valid}>
            {busy ? "Starting…" : "Start run"} {!busy && <ArrowRight size={16} />}
          </button>
          {!valid && topic.length > 0 && <p className="hint mt-2">Add a few more words to the topic.</p>}
        </div>

        <div className="mt-8">
          <div className="flex items-baseline justify-between"><h2 className="font-serif text-lg font-semibold">Recent runs</h2><Link href="/runs" className="text-[13px] text-mute underline">All runs</Link></div>
          <ul className="mt-2 divide-y divide-line">
            {recent.length === 0 && <li className="py-3 text-sm text-mute">No runs yet. Your first one will appear here.</li>}
            {recent.map((r) => (
              <li key={r.id}><Link href={`/runs/${r.id}`} className="block py-3 hover:bg-sunken">
                <p className="line-clamp-2 text-sm font-medium">{r.topic}</p>
                <div className="mt-1.5 flex items-center justify-between"><StatusPill status={r.status} /><span className="text-xs text-faint">{fmtDate(r.created_at)}</span></div>
              </Link></li>
            ))}
          </ul>
        </div>
      </aside>
    </div>
  );
}
