# Groundwork — evidence-grounded multi-agent research assistant

```
groundwork/
├─ frontend/      Next.js 14 + TypeScript + Tailwind (this delivery)
├─ backend/       FastAPI + LangGraph (your existing skeleton goes here)
└─ .github/workflows/frontend.yml
```

## Run the frontend (sample data, no backend)
```bash
cd frontend
npm install
npm run dev          # http://localhost:3000
```
Sample mode is on by default (`NEXT_PUBLIC_USE_MOCK=true` in `.env.local`).
Try topics containing the words **fail** or **pause** to see the failed and paused states.

## Connect the real backend
1. Set `NEXT_PUBLIC_USE_MOCK=false` and `NEXT_PUBLIC_API_URL=http://localhost:8000` in `frontend/.env.local`.
2. Enable CORS for `http://localhost:3000` in FastAPI.
3. Implement the endpoints below. Only `src/lib/api.ts` talks to the backend.

| Endpoint | Returns |
|---|---|
| `POST /runs` `{topic, config}` | `{id}` |
| `GET /runs` | `RunSummary[]` |
| `GET /runs/{id}` | `RunSummary` |
| `GET /runs/{id}/events` | SSE, one `RunEvent` JSON per `data:` line |
| `GET /runs/{id}/report` | `Report` |
| `GET /runs/{id}/diagrams` | `Diagram[]` |
| `GET /runs/{id}/state` (new) | `RunState`: papers, extractions, gaps, hypotheses, critic_verdicts |
| `GET /runs/{id}/evidence/{item}` | `Evidence` |
| `POST /runs/{id}/resume` | 204 |
| `GET/POST /runs/{id}/ratings` | `Rating[]` / 204 |

All shapes are in `frontend/src/lib/types.ts` and mirror Appendix A of the design doc.
Two additions to the design doc's endpoint list: `GET /runs/{id}/state` and `GET /runs/{id}/ratings`.
